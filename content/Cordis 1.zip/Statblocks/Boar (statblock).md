---
draft: "true"
aliases:
---
![[Pasted image 20240312193721.png]]