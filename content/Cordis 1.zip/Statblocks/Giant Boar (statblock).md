---
draft: "true"
aliases:
---
![[Pasted image 20240312193823.png]]