---
draft: "true"
aliases:
---
![[Pasted image 20240412162148.png]]v