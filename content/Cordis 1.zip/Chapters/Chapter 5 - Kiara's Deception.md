---
draft: 
aliases:
---
###### Abridged (WIP)
- Gang met [[Gaffot]] at the [[Rocky Refuge]]
- Gang searched around the Inn for the [[Hooded Man]], end up hearing from [[Sarmon]] that he is residing upstairs
- As they head up stairs to find the man, they run into magic circle traps
- These traps alert the man, who ends up sending a magic blast into the gang
- Fight then ensues
- [[Hooded Man]] ends up dying when [[Brogan Stone-Flask|Brogan]] displaces him mid teleportation spell with a thunderwave
- His body dissolves
- [[Woo Baby Woo|Woo]] puts on the [[Circlet of the Occult]] and becomes paralysed, seeing a vision of eyes and static looking into her soul, [[Brogan Stone-Flask|Brogan]] and [[Ysgarlad]] have to free her
- Gang recovers the [[Fragment of the Eternal Shadow]] from a bag in the room, [[Brogan Stone-Flask|Brogan]] claims a dagger
- [[Sarmon]] comes to inspect the commotion, realising the gang started a brawl and caused damage, he demands reparations of 250GP in the next 3 days, allowing the gang to stay at the inn while they collect money
- The next morning the gang overhears [[Mirabel Emberfall]] crying at the notice board in the inn
- learn from [[Kiara]] that her husband [[Orson]] is missing in the [[Gloomstone Cavern]], which is really why she wanted [[Ysgarlad]]'s help
- the gang agrees to meet her and her friend [[Lunette]] to go find [[Orson]] the next day
- in the mean time they visit the market district of [[Rorkard]]
- They stop at [[Norbert's General]], meeting [[Norbert]], [[Brogan Stone-Flask|Brogan]] buys some nails
- next [[Ironhand Forge]] where they meet [[Francindo]], [[Liri]] gets some new clothes, [[Ysgarlad]] and [[Woo Baby Woo|Woo]] sell the giant boar pelt for 60GP a piece
- next [[Spirit Reader Shanya's]] where they meet [[Shanya]], [[Woo Baby Woo|Woo]] buys a scroll of spiderwalking
- Gang gets their spirit read
- [[Shanya]] gets scared of [[Liri]] while reading her spirit and apologises, begging the gang to leave
- Finally gang visits the [[Cruster Guild]], where [[Crystus]] looks at the [[Fragment of the Eternal Shadow]]
- [[Ysgarlad]] decides to hold onto it
- The next morning at sunrise, the gang meets outside the [[Cruster Guild]] with [[Lunette]] and [[Kiara]], who lead them to [[Gloomstone Cavern]]
- The gang enters the cavern, soon runs into two skeletons, who they deal with pretty fast
- The gang come to a mining station in the cavern, [[Kiara]] and [[Lunette]] end up betraying them, causing the tunnel to collapse, trapping the gang in the room as they run away
- Inside the mining station the gang encounter three brutes, [[Korgar the Spiked Menace]], [[Varthis the Cursed]] and [[Gorbold the Gorgeful]], a bout ensues
- [[Varthis the Cursed]], a necromancer, raises another skeleton to fight for him
- the skeleton turns out to be [[Orson]] recognisable by his red scarf
- after a long gruelling fight and against all odds, the gang manages to come out on top, albeit with [[Brogan Stone-Flask|Brogan]] and [[Woo Baby Woo|Woo]] going down.
- [[Ysgarlad]] revives [[Brogan Stone-Flask|Brogan]] with a health potion, who then in turn revives [[Woo Baby Woo|Woo]] with a healing spell
- The gang loot the bodies of their adversaries, finding 300GP
- [[Brogan Stone-Flask|Brogan]] and [[Woo Baby Woo|Woo]] each take one of [[Orson's Longswords]]
- [[Woo Baby Woo|Woo]] takes the [[Orb of Varthis]]
- [[Ysgarlad]] takes [[Orson's Scarf]] to give to [[Mirabel Emberfall]]
- Left trapped in the cave

*Our story continues in [[Chapter 6 - Meat for Mother]]...*