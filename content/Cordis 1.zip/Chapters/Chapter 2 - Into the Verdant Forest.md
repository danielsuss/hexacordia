---
draft: 
aliases:
---
![[Pasted image 20240418182746.png]]
After a restful night at the [[Sleepy Leaf]] in [[Gilbreives]], we find [[Brogan Stone-Flask|Brogan]], [[Woo Baby Woo|Woo]] and [[Ysgarlad]] in the morning sitting downstairs waiting for breakfast. Just as they get their food, the door to the Inn slams open.
```
Gronk:
	BWAHAHAHAHAHA THERE'S MY FAVOURITE CREW OF REJECTS! AND BY THAT I MEAN THE TWO GOONS DISGRACING THE PRESENCE OF THIS WELL-ENDOWED ELF!
```
[[Gronk Growheart|Gronk]] bursts through the door and paces towards the table where the gang is sat. He laughs and smacks [[Brogan Stone-Flask|Brogan]] on the back just as he takes his first bite of breakfast, causing him to choke and spit it out. He informs the gang that their escort to [[Rorkard]] is waiting at the north gate, and that they should be on their way as soon as they can. After [[Woo Baby Woo|Woo]] decides to steal and chug a tankard of ale from an unsuspecting patron of the inn, the gang makes their way outside and towards the gates.
![[Pasted image 20240305171941.png]]
As they get nearer, five figures come into sight. Two people and three horses. [[Gronk Growheart|Gronk]] immediately strides over to one of the horses and starts nuzzling it and calling it pet names, with the horse responding with a passionate neigh.
```
???:
	I'm guessing that if you've never been in Gilbreives then you won't have seen one of these guys before?
```
A female voice interjects [[Gronk Growheart|Gronk]]'s ogling, and as the gang look over in her direction, they see a woman petting the upper leg and looking fondly at one of the horses. The woman has a slender figure, shoulder length brown hair, green eyes, freckles, earrings reminiscent of leaves of the trees surrounding [[Gilbreives]], and a warm glow around her.
![[Pasted image 20240303214448.png]]
Upon closer inspection, the gang notices that the horse is in fact much larger than a normal horse, about 50% bigger, and has small tusks emerging from its snout.
```
???:
	This here's a special breed called a Tuskhoof, and we've been using them in this village for just about as long as its been around. Their size and extra muscularity makes a good fit for our strongly built men, and also allows for easier transport of our Lumber in large batches.
```
As they are learning about the [[Tuskhoof|Tuskhooves]], another voice interrupts.
```
???:
	Hehehe yeah yeah, and you guys are lucky enough to get to ride with the best Jockey in town!
```
The gang looks over to the right pillar of the gate to see a man leaning on the pillar with his arms folded and his eyes closed. He's wearing a mustard yellow archers hat with a black and grey feather, short brown hair, a curly moustache, carrying a quiver and short bow on his back.
![[Pasted image 20240303214725.png]]
```
???:
	The name's Quin Fellbrook
```
[[Quin Fellbrook|Quin]] turns to look at the gang. As soon as he opens his eyes a startled look shoots across his face.
```
Quin:
	WAIT ITS YOU
```
[[Quin Fellbrook|Quin]] has his arm outstretched with his finger pointing directly at [[Brogan Stone-Flask|Brogan]], who starts laughing. [[Quin Fellbrook|Quin]] looks back and forth between [[Brogan Stone-Flask|Brogan]] and the green-eyed woman, with his brow scrunched, before waving his arms up and down and starting to shout.
```
Quin:
	Don't tell me I have to spend 3 days with this rat! This cheat of a dwarf humiliated me by slipping something in my drink yesterday!
```
[[Quin Fellbrook|Quin]] protests the woman, who is now glaring at [[Brogan Stone-Flask|Brogan]]. She seems to recognise him as well and does not have an impressed look on her face. Ultimately, she decides to ignore [[Quin Fellbrook|Quin]] and introduces herself as [[Rowena Growheart]], [[Gronk Growheart|Gronk]]'s wife. [[Rowena Growheart|Rowena]] explains that [[Quin Fellbrook|Quin]], [[Gronk Growheart|Gronk]] and herself will be accompanying the gang through the [[Verdant Forest]], about half way to their destination of [[Rorkard]]. [[Woo Baby Woo|Woo]] walks over to her with a glint in her eye and serenades [[Rowena Growheart|Rowena]]. [[Rowena Growheart|Rowena]] looks at [[Woo Baby Woo|Woo]] with a puzzled look. The rest of the gang laughs. [[Gronk Growheart|Gronk]] walks over to [[Woo Baby Woo|Woo]] and starts looking at her with a sultry look on his face.
```
Gronk:
	Three days, you're gonna ride with me right? Little lady.
```
[[Woo Baby Woo|Woo]] does not look happy. [[Brogan Stone-Flask|Brogan]] points out [[Gronk Growheart|Gronk]]'s behaviour to [[Rowena Growheart|Rowena]], who promptly walks over and slaps him. After a brief discussion with [[Gronk Growheart|Gronk]] about keeping his misogynistic behaviour, [[Woo Baby Woo|Woo]] decides to ride the three days on [[Rowena Growheart|Rowena]]'s horse. While they are saddling up, the gang sees [[Quin Fellbrook|Quin]] on his horse already, staring out of the gate and into the [[Verdant Forest]]. [[Brogan Stone-Flask|Brogan]] seizes this opportunity. He runs towards [[Quin Fellbrook|Quin]]'s horse, and prepares himself to make a leap onto [[Quin Fellbrook|Quin]]'s Saddle. [[Quin Fellbrook|Quin]] sees this and ushers the Horse to start moving, however the horse only starts trotting away. [[Brogan Stone-Flask|Brogan]] makes a leap, however the only thing in reach is the horses tail, which he firmly clings onto. Startled, the horse starts galloping out of the gate, [[Brogan Stone-Flask|Brogan]] hanging on and bouncing behind the Horse like a speedball. With some effort he manages to rope climb up the tail and hoists himself onto [[Quin Fellbrook|Quin]]'s saddle. He locks his knees into [[Quin Fellbrook|Quin]]'s, and as the Horse continues to gallop off, the rest of the group waiting at the gate hears [[Quin Fellbrook|Quin]]'s angered screams getting quieter and quieter. [[Gronk Growheart|Gronk]] laughs. As they set out of the gate together, [[Rowena Growheart|Rowena]] rejects more of Woo's advances. [[Ysgarlad]] and [[Gronk Growheart|Gronk]] discuss their seating arrangement. [[Gronk Growheart|Gronk]] is avid on being big spoon. Trying to persuade him otherwise, [[Ysgarlad]] fails, [[Gronk Growheart|Gronk]] explaining that they need to "bond". Reluctantly, [[Ysgarlad]] climbs onto the horse in [[Gronk Growheart|Gronk]]'s lap, which then proceeds to make its way out of the gate.
![[Pasted image 20240305175936.png]]
As the gang sets out into the [[Verdant Forest]], they are met with a pleasant breeze and the subtle scent of pine trees. They can hear the trees swaying in the wind, as well as the crashing yet calming sound of the river flowing downstream.
```
Gronk:
	Ahhhhhh, nothing like riding ol' Gronkus Maximus through the Verdant Forest on a calm morning!
```
```
Rowena:
	I told you to change the name of that dumb brute of a horse, not make it longer.
```
The calmness has suddenly been interrupted by the bickering of the Growhearts, through which the gang learns that the name of [[Gronk Growheart|Gronk]]'s horse is also [[Gronk Growheart|Gronk]]. [[Gronk Growheart|Gronk]] explains that he named it [[Gronk Growheart|Gronk]] to reflect its "outstanding strength" and "overwhelming charisma". They continue to argue for a little while before [[Gronk Growheart|Gronk]] finally submits.
```
Gronk:
	Alright alright enough enough. I'll change Gronky Boy's name okay, happy? Anyway, my Motley crew, take a look down to your left, you see that river? Thats the River Midwood. Follow that, and it'll take you all the way to Rorkard.
```
![[Pasted image 20240305181901.png]]
After a peaceful journey alongside the [[River Midwood]], as the evening sets in the gang decides to settle down in a spot to camp for the night. [[Rowena Growheart|Rowena]] lights a camp fire with her magic, and [[Quin Fellbrook|Quin]] decides to start cooking claiming that he is the best cook. After eating their fill, [[Woo Baby Woo|Woo]] suggests the gang plays poker. This ends in [[Woo Baby Woo|Woo]] wiping the floor with the rest of the game members, raking in a profit of three gold and one silver pieces from [[Brogan Stone-Flask|Brogan]], [[Quin Fellbrook|Quin]] and [[Gronk Growheart|Gronk]]. As a feeling of contempt and slight drowsiness washes over the gang, they settle down for the night, with [[Gronk Growheart|Gronk]] and [[Quin Fellbrook|Quin]] alternating night watch.
![[Pasted image 20240305175936.png]]
The second day of riding is quite uneventful, with the only changes being the following:
[[Gronk Growheart|Gronk]] has started to rest the stump of his right arm on [[Ysgarlad]]'s shoulder, claiming that they are bonding. Everyone is growing increasingly tired of hearing [[Quin Fellbrook|Quin]] yap on about his accolades. [[Rowena Growheart|Rowena]] confides in [[Woo Baby Woo|Woo]] whilst complaining about [[Gronk Growheart|Gronk]]. [[Woo Baby Woo|Woo]] baby woo listens calmly.
![[Pasted image 20240305181901.png]]
Before long it is the evening and camp has been set up again. While sitting around the fire eating soup made by [[Quin Fellbrook|Quin]], the gang hears a large sigh from [[Gronk Growheart|Gronk]].
```
Gronk:
	AHHHHHHHHHHHHH DELICIOUS AS EVER QUIN YUMMY. GRONK! ehem, I mean, Cuthbert, come and try this soup!
```
[[Gronk Growheart|Gronk]] keeps yelling the name Cuthbert in the direction of his horse, who is drinking water from the river. A look of sadness falls upon him when the horse doesn't respond to his calls. He looks over at [[Rowena Growheart|Rowena]], almost crying, who returns an unphased smug look. Snapping out of it, he roars into conversation again.
```
Gronk:
	ALRIGHT, MIGHTY WARRIORS, ITS TIME FOR A GAME. ONE OF MY INVENTION. I CALL IT, SHEARS PARCHMENT PEBBLE! IT'S ABSOLUTELY RIVETTING! ON THE COUNT OF THREE EACH PLAYER MAKES ONE OF THE THREE OPTIONS WITH THEIR HAND, AND THE WINNER IS DECIDED AS FOLLOWS: SHEARS BEATS PARCHMENT, PARCHMENT BEATS PEBBLE, AND PEBBLE BEATS SHEARS. LOSER HAS TO TAKE GUARD DUTY! 
```
[[Rowena Growheart|Rowena]] and [[Quin Fellbrook|Quin]] look completely disinterested.
```
Gronk:
	AHAHAHAHAHA BUT AS THE INVENTOR OF THIS FEAT OF BRILLIANCE, IT WOULD BE UNFAIR OF ME TO PLAY. YOU THREE, PLAY EACHOTHER! ILL TAKE THE SECOND HALF OF THE NIGHT!
```
The gang ends up playing [[Shears Parchment Pebble]], and [[Ysgarlad]] loses. As the night comes to a close, he sits down at a tree, ready to guard the camp.
![[Pasted image 20240307192632.png]]
A few hours later, [[Ysgarlad]] hears a rustling coming from the direction of the horses. Upon closer inspection, he sees a wild [[Boar]] helping itself to the gangs rations. He promptly scares it off. Another hour passes, and [[Ysgarlad]] hears the rustling again. A different boar has appeared, this one not looking so willing to run away. It has a malicious look in its eyes. [[Ysgarlad]] draws his sword ready for combat.
![[Pasted image 20240419142043.png]]
The [[Boar]] was resilient, with [[Ysgarlad]] becoming increasingly frustrated by the [[Boar]] getting back up after his numerous hits. After a surprisingly long fight, [[Ysgarlad]] triumphed unscathed, blocking or dodging all of the [[Boar]]'s attacks. [[Ysgarlad]] swapped guard duty with [[Gronk Growheart|Gronk]], who butchered the boar, and the rest of the night passed without a hitch. The third day of travel passed much like the first two, and the gang found themselves stopping to rest in the evening again. As [[Quin Fellbrook|Quin]] starts cooking again, he challenges [[Brogan Stone-Flask|Brogan]] to a competition. Whoever can eat the most food spiked with [[Quin's Spice Blend]] will win.
```
Quin:
	If you win i'll give you a bag of my famous spice blend. However if I win, you're never to lay your hands on Wren Briarwood ever again, and you have to tell her how great of a man I am!
```
Confused, [[Brogan Stone-Flask|Brogan]] asks who [[Wren Briarwood]] is, and [[Quin Fellbrook|Quin]] reveals that it is the girl who's face he saw [[Brogan Stone-Flask|Brogan]] caressing just after he humiliated him in the drink off. [[Gronk Growheart|Gronk]] laughs and interjects.
```
Gronk:
	BWAAHAHAHAHAH Who would've thought that the fearless Quin was a wuss when it comes to being a real man! 
```
[[Quin Fellbrook|Quin]] explains that they grew up around each other but she never noticed him, so now he thinks she hates him and is scared to approach her. [[Gronk Growheart|Gronk]] laughs again. He bets on [[Brogan Stone-Flask|Brogan]] to win and states that if [[Quin Fellbrook|Quin]] wins he'll personally go tell the girl to acknowledge him. [[Ysgarlad]] decides to eat the spicy food as well, but only to prove a point and not as a competition. [[Quin Fellbrook|Quin]] ends up tapping out first, with [[Brogan Stone-Flask|Brogan]] eating most of the food, and [[Ysgarlad]] asking for seconds. [[Quin Fellbrook|Quin]] is humiliated again and hands over his special spice blend to [[Brogan Stone-Flask|Brogan]]. [[Ysgarlad]] settles for guard duty again. A couple hours into the night, he hears a familiar sound. This time he sees three [[Boar|Boars]], and decides to wake [[Brogan Stone-Flask|Brogan]] and [[Woo Baby Woo|Woo]] to aid him in battle. [[Brogan Stone-Flask|Brogan]] takes the initiative, making some distance towards the pack before stopping to throw his dagger at the closest [[Boar]]. The dagger hits, but hits with the pommel and bounces off, leaving the [[Boar]] unwounded. [[Ysgarlad]] follows up by charging at the pack, and slashes his sword through one of the boars' legs, cutting a shallow wound. Enraged at [[Brogan Stone-Flask|Brogan]], the first [[Boar]] charges, and digs its tusk deep into his thigh. Seeing this, [[Woo Baby Woo|Woo]] responds with a magic missile spell, taking the [[Boar]] out with three projectiles of magical energy. Seeing his [[Boar]] brother perish, the [[Boar]] hurt by [[Ysgarlad]] charges at [[Brogan Stone-Flask|Brogan]], however [[Ysgarlad]] takes this opportunity to finish it off with another slash of his sword. Now staring at the corpses of its brethren, the largest and final [[Boar]] charges towards [[Brogan Stone-Flask|Brogan]], however not before taking a hit from [[Ysgarlad]]. Reaching [[Brogan Stone-Flask|Brogan]], it digs its tusk into the wound in his leg left by the first [[Boar]], going clean through. This causes [[Brogan Stone-Flask|Brogan]] to keel over in pain, and faint. [[Woo Baby Woo|Woo]] retaliates with a ray of frost, injuring it gravely, however not taking it out. [[Ysgarlad]] makes a final attempt to kill the [[Boar]] with a swing of his sword, but misses. The [[Boar]], realising its mortality, flees. [[Woo Baby Woo|Woo]] tries to hit it with another long ranged ray of frost, but whiffs. [[Ysgarlad]] picks up [[Brogan Stone-Flask|Brogan]]'s dagger, and runs over to his aid. He carries [[Brogan Stone-Flask|Brogan]] back to the camp, where [[Rowena Growheart|Rowena]] promptly heals his leg, causing the muscle fibres to reform. [[Brogan Stone-Flask|Brogan]] wakes with a startled look on his face, and receives comfort and reassurance from the rest of the gang.  three wake up [[Gronk Growheart|Gronk]], and return to their bedrolls for rest.
![[Pasted image 20240305175936.png]]
The morning comes, and so does the departure of [[Gronk Growheart|Gronk]], [[Rowena Growheart|Rowena]] and [[Quin Fellbrook|Quin]] to head back to [[Gilbreives]]. After recapping what happened in the night, [[Quin Fellbrook|Quin]] laughs and tells [[Brogan Stone-Flask|Brogan]] that it was deserved. Goodbyes and good lucks are said, and before long the gang finds themselves on their own for the next half of the journey.

*Our story continues in [[Chapter 3 - The Dangling Tradesman]]...*