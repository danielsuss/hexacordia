---
draft: 
aliases:
---
![[Berserker Potion.webp]]
###### Overview
- An bright orange potion which affects the consumer in the following ways for 1 minute:
	- Advantageous strength
	- Advantageous melee weaponry
	- Increased resistances to physical attacks
	- Inability to concentrate on or cast spells