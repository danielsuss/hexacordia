---
draft: 
aliases:
---
###### Overview
- A special crystal found on the [[Arid Continent]]
- It has special properties that give it a variety of uses, such as the [[Aetherquartz Ring]]