---
draft: 
aliases:
---
![[Quin's Spice Blend.webp]]
###### Overview
- A special blend of spices made by [[Quin Fellbrook]]. He claims they do something special depending on how you ingest them
- Used in an eating contest between [[Brogan Stone-Flask|Brogan]] and [[Quin Fellbrook|Quin]] to see who could eat the most spicy food
- [[Brogan Stone-Flask|Brogan]] won, taking a pouch of [[Quin's Spice Blend]] as a prize
- Not much is known about the effects of ingesting these spices