---
draft: 
aliases:
---
![[Aetherquartz Ring 2.webp]]
###### Overview
- A sparkling pale blue crystal dust to be used in conjunction with an [[Aetherquartz Ring]] to allow for tracking of entities
- It is hard to detect and harder to wash off
- Used by [[Hoagle]] to help the gang track a group of [[Kobold|Kobolds]] who stole his magic bag in the [[Verdant Forest]]
- [[Brogan Stone-Flask]] used it on [[Lunette]] after escaping [[Gloomstone Cavern]], before learning that she was innocent