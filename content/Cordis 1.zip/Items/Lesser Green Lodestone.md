---
draft: "true"
aliases:
---
- when applied to apparel
	- once per long rest can be used as a reaction or bonus action to dash up to 10ft with a blast of wind
- when applied to a weapon
	- once per long rest can be used to increase weapon speed, effectively reducing the target's AC by 4 for that hit roll, and adding 2 damage to the subsequent damage roll