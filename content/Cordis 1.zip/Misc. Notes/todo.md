---
draft: "true"
aliases:
---
#hidden 
- [ ] calendar
- [x] write up chapter 2
- [x] chapter 3 notes
- [x] winged kobold hex
- [x] kobold camp battle map
- [x] kobold camp trap design
- [x] cabin in woods landscape
- [x] rorkard landscape
- [x] garden at night landscape
- [x] garden at night battle map
- [x] character design - sprite
- [x] character design - Hoagle's friend
- [x] item design - Hoagle's friends house
- [x] item design - kobold camp
- [x] item design - Hoagle's shop
- [x] music choice for different scenes
- [x] plots for rorkard
- [x] Item design for korgar's greatclub and varthis orb
- [x] Rorkard theives guild