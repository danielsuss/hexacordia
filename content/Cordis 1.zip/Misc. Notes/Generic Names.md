---
draft: "true"
aliases:
---
1. Elowen Blackwood
2. Lunette Emberfall
3. Jocelyn Highpeak
4. Mirabel Moonshadow
5. Nerissa Dragonheart
6. Mirabel Copperpot
7. Elowen Kingshaven
8. Giselle Oakenshield
9. Oriana Grimwater
10. Davina Grimwater
11. Isolde Copperpot
12. Celestine Blackwood
13. Kiera Ironhand
14. Giselle Highpeak
15. Mirabel Nightsilver ​

1. Jasper Ironhand
2. Leofric Proudmoore
3. Falk Highpeak
4. Emeric Copperpot
5. Orson Jadeeye
6. Merrick Grimwater
7. Cedric Ironhand
8. Cedric Moonshadow
9. Ivor Emberfall
10. Emeric Proudmoore
11. Merrick Emberfall
12. Norbert Nightsilver
13. Norbert Emberfall
14. Merrick Jadeeye
15. Hadrian Blackwood