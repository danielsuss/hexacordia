---
draft: 
aliases:
---
![[Pasted image 20240305175936.png]]
###### Overview
- One of the three main rivers emerging from [[Florion's Tear]] on the [[Verdant Continent]]
- The [[River Midwood]] runs through the middle of the [[Verdant Forest]] as the name suggests
- Connects a direct route from [[Rorkard]] to [[Gilbreives]]