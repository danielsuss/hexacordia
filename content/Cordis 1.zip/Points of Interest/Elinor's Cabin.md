---
draft: 
aliases:
---
![[Pasted image 20240423003101.png]]
###### Overview
- A cabin in the [[Verdant Forest]], home to [[Elinor]]
- The gang stayed here for a night after dealing with a [[Boar]] infestation for [[Elinor]] during their journey to [[Rorkard]]
###### Gallery
|                                                          |                                                                        |
| -------------------------------------------------------- | ---------------------------------------------------------------------- |
| *[[Elinor's Cabin]]*![[Pasted image 20240423003101.png]] | *[[Elinor\|Elinor's]] Crop Garden*![[Pasted image 20240423013153.png]] |