###### Overview
- The [[Great Tree of Gilbreives]] is a giant sacred tree in the centre of [[Gilbreives]]
- Every year the winner of the [[Lumber Festival|wood chopping competition]] gets to swing the [[Emerald Axe]] at the tree
- It has only been cut 82 times, due to the 83rd annual [[Lumber Festival]] being interrupted by the [[Hooded Man|Hooded Man's]] antics