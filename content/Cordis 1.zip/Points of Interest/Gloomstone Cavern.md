---
draft: "true"
aliases:
---
![[Pasted image 20240610203027.png]]
###### Overview
- [[Gloomstone Cavern]] is a cavern just outside [[Rorkard]], and is a popular place to mine for crystals, often done by the [[Cruster Guild]]