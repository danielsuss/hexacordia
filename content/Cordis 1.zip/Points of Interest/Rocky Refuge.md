---
draft: "true"
aliases:
---
![[Pasted image 20240610201559.png]]
###### Overview
- The [[Rocky Refuge]] is an inn owned by [[Sarmon]] in the town of [[Rorkard]]
- It is a popular meeting place and info hub for the people of [[Rorkard]], as well as a popular inn in general
- The gang found and fought the [[Hooded Man]] here, leading to his death and the destruction of one of the rooms