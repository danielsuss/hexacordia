---
draft: 
aliases:
---
![[Pasted image 20240418150624.png]]
###### Overview
- The main meeting place for the people of [[Gilbreives]]
- [[Grink Growheart|Grink]] can often be found sitting or sleeping on the throne at the end of the town hall
- Has a treasure room hidden behind a bookshelf at the end of the hall
- When [[Ysgarlad]] visited the treasure room he found two guards there