---
draft: "true"
aliases:
---
*Large Beast [[Verdant Forest]]*
![[Pasted image 20240610200647.png]]
###### Overview
- A rare, extra large and fierce variant of the [[Boar|Boars]] found in the [[Verdant Forest]]
- Their strong pelt is sought after by armorers and fashioners as a material for their crafts
- The gang fought and killed a [[Giant Boar]] while they were defending [[Elinor's Cabin]] during their journey to [[Rorkard]]
