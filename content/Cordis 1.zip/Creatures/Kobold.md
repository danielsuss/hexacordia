---
aliases:
  - Kobolds
draft:
---
*Small Beast ???*
![[Pasted image 20240423004856.png]]
###### Overview
- [[Kobold|Kobolds]] are small bipedal lizard-like creatures, adept at making traps and getting up to mischief
- The gang fought and killed a group of them who stole [[Hoagle|Hoagle's]] magic bag in the [[Verdant Forest]] during their journey to [[Rorkard]]
- Although they were encountered there, according to [[Elinor]], they are not native to the [[Verdant Forest]]

*See also [[Winged Kobold]]*