---
draft: "true"
aliases:
  - Goblins
---
