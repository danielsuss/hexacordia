---
aliases:
  - Tuskhooves
draft:
---
###### Overview
- A special breed of horse used by the people of [[Gilbreives]]
- They are about 50% larger and more muscular than a normal horse, with short tusks emerging from the muzzle
- They have a wild temperament and have to develop a special bond with an individual before they can be ridden
- Traditionally used by town of [[Gilbreives]] as they can accommodate the heavier well built lumberjack men and can be used to drag heavy carts of lumber
- They roam wild in the [[Verdant Forest]]
- Ridden by the gang along with [[Gronk Growheart|Gronk]], [[Rowena Growheart|Rowena]] and [[Quin Fellbrook|Quin]] during the first part of their journey to [[Rorkard]]