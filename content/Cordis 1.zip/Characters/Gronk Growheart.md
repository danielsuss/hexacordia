---
aliases:
  - Gronk
---
*Human Male 36 [[Gilbreives]]*
![[Pasted image 20240229220442.png]]
> *Damn little lady, without me? BWAHAHAHAHAHAHAHA!*
###### Overview
- [[Gronk Growheart]] is the son of [[Grink Growheart]] and a man from [[Gilbreives]]
- His wife is [[Rowena Growheart]]
- He lost his right arm trying to prevent the [[Hooded Man]] from escaping with the [[Fragment of the Eternal Shadow]]
- He guided the gang through the thick part of the [[Verdant Forest]] for three days during their journey to [[Rorkard]]
- Has a [[Tuskhoof]] named [[Gronk Growheart|Gronk]]