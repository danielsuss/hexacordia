---
draft: "true"
aliases:
---
gaffot 