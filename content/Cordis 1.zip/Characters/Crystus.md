---
draft: "true"
aliases:
---
*Human Male 60 [[Rorkard]]*
![[Pasted image 20240610205904.png]]
> **
###### Overview
- [[Crystus]] is the leader of the [[Cruster Guild]] in [[Rorkard]]
- Was originally met by the gang and treated rudely by [[Ysgarlad]] upon their entrance to [[Rorkard]], as [[Ysgarlad]] did not know who he was and thought he was a beggar
- 