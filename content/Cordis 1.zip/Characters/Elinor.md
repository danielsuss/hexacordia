---
draft: 
aliases:
---
*Human Female 65 [[Verdant Forest]]*
![[Pasted image 20240423003243.png]]
> *Please, do come in for some tea and biscuits!*
###### Overview
- [[Elinor]] is a woman who lives in a [[Elinor's Cabin|Cabin]] in the [[Verdant Forest]]
- She is friends with [[Hoagle]]
###### [[Chapter 4 - Rorkard at Last]]
- She provided the gang with food, refuge and gold, in exchange for dealing with the [[Boar|Boars]] that were ruining her crop garden
- She gave [[Ysgarlad]] a cake to deliver to [[Sarmon]]