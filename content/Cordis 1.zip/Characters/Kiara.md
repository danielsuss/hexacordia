---
draft: "true"
aliases:
  - Kiara's
---
*Human Female 22 [[Rorkard]]*
![[Pasted image 20240610202251.png]]
> *For my family's legacy, I will crush [[Rorkard]]!*
###### Overview
- [[Kiara]] is a mage from [[Rorkard]] 
- Upon their first meeting, she asked [[Ysgarlad]] for help to carry crystals out of [[Gloomstone Cavern]]