---
aliases: 
draft:
---
*Gnome Male 28 ???*
![[Pasted image 20240305173822.png]]
> *Ain't no hagglin' with Hoagle!*
###### Overview
- [[Hoagle]] is a travelling trader with a magic bag that transforms into his trading stall
- The gang helped [[Hoagle]] to get his bag back when it was stolen a gang of [[Creatures/Kobold|Kobolds]] in the [[Verdant Forest]]
- Gave [[Brogan Stone-Flask|Brogan]] an [[Aetherquartz Ring]]
- Gave [[Woo Baby Woo|Woo]] an [[Odd Stone]]
- Travelled with the gang through the [[Verdant Forest]] until they reached [[Elinor's Cabin]]