---
draft: 
aliases:
---
*Human Male ??? ???*
![[Pasted image 20240418140155.png]]
> *The world will soon drown in the shadow of the occult.*
###### Overview
- The [[Hooded Man]] stole the [[Fragment of the Eternal Shadow]] from the [[Emerald Axe]] in [[Gilbreives]] during the [[Lumber Festival]], his motive unknown
- During his escape he teleported away, cutting off [[Gronk Growheart|Gronk's]] right arm in the process
- Was found by the gang 2 weeks later resting at the [[Rocky Refuge]] in [[Rorkard]]
- A battle ensued where he used mysterious powers from the [[Circlet of the Occult]]
- Was killed by [[Brogan Stone-Flask|Brogan]] with a thunderwave as he tried to escape by teleporting again
- Left behind the [[Circlet of the Occult]] as well as the stolen [[Fragment of the Eternal Shadow]]