---
aliases:
  - wren
draft:
---
*Human Female 21 [[Gilbreives]]*
###### Overview
- [[Wren Briarwood]] is a woman from [[Gilbreives]] and the love interest of [[Quin Fellbrook]]
- She was comforted by [[Brogan Stone-Flask|Brogan]] during the events of the 83rd annual [[Lumber Festival]], causing [[Quin Fellbrook|Quin]] to hold a grudge against [[Brogan Stone-Flask|Brogan]]