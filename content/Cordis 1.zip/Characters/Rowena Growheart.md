---
aliases:
  - Rowena
draft:
---
 *Human Female 34 [[Gilbreives]]*
![[Pasted image 20240303214448.png]]
> *The fire in my heart will shelter Gilbreives from harm.*
- [[Rowena Growheart]] is a mage from [[Gilbreives]]
- Her husband is [[Gronk Growheart]]
- The gang has seen her using fire and healing magic
- Was part of the group that travelled with the gang through the thick part of the [[Verdant Forest]] on their journey to [[Rorkard]]
- Healed [[Brogan Stone-Flask|Brogan's]] leg after it was impaled by a [[Boar]] in the [[Verdant Forest]]