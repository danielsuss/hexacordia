---
draft: "true"
aliases:
---
*Sprite Female 10 ???*
![[Pasted image 20240423002234.png]]
> *Woaaaaah that was so cool!!*
###### Overview
- [[Liri]] is a sprite that the gang found trapped in a cage after killing the [[Kobold|Kobolds]] who stole [[Hoagle|Hoagle's]] bag
- [[Ysgarlad]] set her free however she came back to the gang after a day or so during their journey through the [[Verdant Forest]] towards [[Rorkard]] in search of food
- [[Liri]] decided to join the gang on their adventure after they showed her kindness
- She helped [[Ysgarlad]] deliver a cake to [[Sarmon]] as requested by [[Elinor]]
- She was given a blue gem by [[Brogan Stone-Flask|Brogan]] which he stole from the [[Cruster Guild]]
- 