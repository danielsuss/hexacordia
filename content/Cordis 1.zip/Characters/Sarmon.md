---
draft: "true"
aliases:
---
*Human Male 34 [[Rorkard]]*
![[Pasted image 20240610200031.png]]
> *As long as they're a paying patron, anyone is welcome at the [[Rocky Refuge]]!*
###### Overview
- [[Sarmon]] is a man who lives in [[Rorkard]] and the owner of the [[Rocky Refuge]]
- He was delivered a cake from [[Elinor]] by [[Ysgarlad]] and [[Liri]]