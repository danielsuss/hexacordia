---
draft: 
aliases:
  - Amara's
---
*Human Female 24 [[Bay of Groves]]*
![[Pasted image 20240416144334.png]]
> *I will... Kiara...*
###### Overview
- [[Amara]] is an adventurer from the [[Bay of Groves]]
- The gang rescued her when they found her being tortured and eaten alive by [[Morgrith the Mother]] and [[Morgrith's Servant]] in [[Gloomstone Cavern]]
- She was betrayed and trapped in [[Gloomstone Cavern]] by [[Kiara]], and was the only one of her party not to be killed and eaten by the cannibals, instead suffering from their torture for weeks
- The gang brought her to [[Rorkard]] to be healed by [[Shanya]]
- [[Ysgarlad]] swore to her that they would get their revenge on [[Kiara]]
###### Gallery
| *Rescued from [[Gloomstone Cavern]]*<br>![[Pasted image 20240416144334.png]] | *Healed in [[Rorkard]]*<br>![[Amara.webp]] |
| ---------------------------------------------------------------------------- | ------------------------------------------ |
