---
draft: "true"
aliases:
---
![[cruster guild 1.webp]]
###### Overview
- The [[Cruster Guild]] is a miner's guild in [[Rorkard]] run by [[Crystus]]