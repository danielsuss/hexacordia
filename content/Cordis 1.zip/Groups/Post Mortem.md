---
draft: "true"
aliases:
---
###### Overview
- An underground information syndicate running through Cordisalia, to which [[Woo Baby Woo|Woo]] has ties
- In [[Gilbreives]] there is an information outpost in the southern part, run by a man disguised as a child
- [[Woo Baby Woo|Woo]] used this outpost to request the syndicate to keep lookout for the [[Hooded Man]]
- In [[Rorkard]], [[Woo Baby Woo|Woo]] was delivered a letter by a grey cat, stating:
	- *"The one you seek rests within the inn"*
- The letter also contained a symbol known as the Eye of Mortem
###### Gallery
|                                                      |                                         |
| ---------------------------------------------------- | --------------------------------------- |
| *Cat in Rorkard*![[Pasted image 20240610205443.png]] | *Eye of Mortem*![[eye of mortem 1.gif]] |
