---
draft: "true"
---
### [[Gilbreives]]

#### Opener

`Improv of old greywolf yolked man making mysogynist remark and swinging the emerald axe into the great tree of gilbreives`
- Crowd gathered around him bursts into laughter, however four people stand out for not laughing
- Attention turns to the four not laughing
	- A dwarf with two mugs of ale in one hand and turning over a coin in the other
	- a genetically gifted elf in the chest department
	- a human who seems to be minding his own business
	- a hooded character in all black whose only defining feature is a small tuft of black beard hair
- The grizzly man slams down his mug of ale, vibe is tense
`Improv of old clearly drunk - You four, I tell that story at the lumber festival every year, and never before have i seen anyone left unsatisfied. Just who do you think you are? Dwarf you look like you know how to handle yourself around a festival, explain yourself, to whom do i owe the pleasure?`
`Improv continues to introduce the other characters`
- by the time they are finished, the [[Hooded Man (statblock)]] is nowhere to be seen, old man notices but thinks he is just drunk.
Introduces himself as [[Gronk Growheart]] stands up and reaches out to shake everyones hand, makes crude remark at elf
`you lot clearly seem from out of townm so let me tell you how things work around here. this is the 83rd annual lumber festival of Gilbreives. a festival where drinking, chopping wood, (and laying wood) AHEM go hand in hand`
- with that all of the ladies swooned, and [[gronk growheart]] starts laughing shooting the ladies looks and bouncing his pecks up and down
`Ahem, anyhowm to you three i say welcome to the town of Gilbreives, please enjoy the festival!`
- everyone lifts up their mug and cheers
- everyone goes back to chatting and drinking and the vibe returns to normal, overhearing the main conversation topic seems to be the [[Lumber Festival|wood chopping competition]] which will take place this afternoon

#### Plot 1 - The gang enters the competition
- roll strength to see how much wood is chopped
- winner gets to take a swing with the [[Emerald Axe]] from the town hall of gilbreives at the [[Great Tree of Gilbreives]]
- when swing is taken the axe bounces off
- crowd shreiks
- gronk realizes the axe is fake
- gang is taken to the great hall where they meet gronk's father, [[Grink Growheart|Grink]] old shrivelled man who leads the town
- when they go into the treasure room of the great hall where the axe is stored, they find two guards unconcious
- upon waking up the guards explain that they were ambushed by the [[Hooded Man (statblock)]], with only one of them have seen him
- in the blink of an eye they were asleep
- grink asks them to retreive the axe, for a reward
- man makes his way towards the city of [[Rorkard]]

#### Plot 2 - The gang looks for the hooded man
 - roll perception to see if they see him
 - if found he still manages to steal the axe, however not without a fight
 - [[Gronk Growheart|Gronk]] gets a hold of the man with one arm
 - the man pulls the purple orb out of the axe, mutters a spell. and teleports away, ripping off gronks arm in the process. 
 - [[Grink Growheart|Grink]] asks them to investigate why the man wanted the purple stone
 - crystal collector friend [[Crystus]] of the [[Cruster Guild]] in the mountainside town of [[Rorkard]] 

#### Overarching plot
- [[Hooded Man (statblock)]] wants axe as it has a [[Fragment of the Eternal Shadow]] in it
- after the gang finds him, if they beat him, he teleports away after taking the purple gem out of the top of the axe, if not he knocks them all out and takes the axe