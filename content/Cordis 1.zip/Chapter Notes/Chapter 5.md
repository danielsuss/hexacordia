---
draft: "true"
---
### Preface
- Gang helped Elinor by killing the boars
- finally made it to Rorkard and were greeted by a fisherman
- [[Ysgarlad]] and [[Liri]] Delivered a cake to [[Sarmon]] at the [[Rocky Refuge]]
- [[Ysgarlad]] approached by [[Kiara]] requesting help in 2 days time to carry crystals out of [[Gloomstone Cavern]]
- [[Brogan Stone-Flask|Brogan]] and [[Woo Baby Woo|Woo]] made some money by cheating a gambler called [[Merek]] at his own game
- [[Woo Baby Woo|Woo]] was delivered a secret note by a cat from [[Post Mortem]] stating that the [[Hooded Man]] is resting in the tavern
- The gang reconvened at the [[Cruster Guild]], seeking out [[Crystus]], end up running into the fisherman again, who turns out to be [[Crystus]]
- [[Woo Baby Woo|Woo]] asks [[Crystus]] about the [[Odd Stone]], he says its a special type of ancient runic stone called a [[Lodestone]] that can be used to make special equipment
- The gang ask [[Crystus]] about the [[Fragment of the Eternal Shadow]], he tells them a about [[The Coalescence]]
- [[Brogan Stone-Flask|Brogan]] steals a blue gem for [[Liri]]
- The gang return to the [[Rocky Refuge]] in search of the [[Hooded Man]]
### Characters

### Items

### Points of Interest

### Story Progression
- Deal with the [[Hooded Man (statblock)]] and make contact with the [[Circlet of the Occult]]
- Put [[Liri]] in a life or death situation to activate the shadow inside of her

### Plot 1 - The Hooded Man
- The gang can get his specific room from persuading [[Sarmon]] - he also tells them that he saw the man crouched over in the corners of the hallways looking shady while he was moving in
- He's in room 7, at the end of the hall
- Rigged the hallway with surveillance magic circles - if triggered he will blast the gang when they open his door
- if avoided - he will be on the floor meditating when they open the door
- when he uses a spell - causes him to wince in pain and blood to drip from his forehead where the gem of the circlet is
- blocks all the gangs attacks with magic skin, however this causes the blood to grow even more
- eventually he tries to teleport away - if brogan uses [[Aetherquartz Powder]], he successfully gets the teleport off, but winces in pain mid way, causing the teleport to shrink and cut off his feet - ring leads them to down by the river
- if brogan doesn't use the powder, he winces in pain causing the teleport to shrink and cut a hole in his stomach, causing him to die "The Occult is inevitable. The world as you know it will drown in shadow."
- just before he dies, the circlet grows bright pink, runes sprawl his body, and burns through and disintegrates his body, causing him to scream in pain
- the only thing that remains at the end is trousers, shoes, and the circlet
- damages to the inn mean that [[Sarmon]] is looking for payment or a favour 

## The Day After

- the gang is eating lunch in the tavern when they see a lady crying at the notice board pinning up a photo
- see [[Kiara]] go over and start comforting the lady, hear [[Sarmon]] sighing from the bar
- Someone explains what happened - that's [[Mirabel Emberfall]], her husband [[Orson]] is a valued warrior in the town of [[Rorkard]]
- Two weeks ago he went missing, was last seen entering [[Gloomstone Cavern]] along with two other men
- [[Kiara]] says that the real reason she wanted [[Ysgarlad]]'s help was to find [[Orson]]
- If whatever in the cavern was strong enough to get [[Orson]], her and her friend wouldn't be able to take it on alone
- she points towards her friend who is sitting at one of the tables in the tavern
- reaffirms that they will help her find [[Orson]] the next day, and that they will meet outside the [[Cruster Guild (Location)]] at sunrise

## The Notice Board
- "Spirit Reader Shanya's is back in business! Stop by to be enlightened about your inner being, or for anything mystical and magical!"
- "Looking for miners - Crystus Cruster Guild"
- "Come get your everyday goods for cheap at Norbert's General"
- "All things attire, functionable and fashionable - Ironhand Forge"

### Plot 2 - Shopping
#### Spirit Reader Shanya's
- Can buy magic items and scrolls here
- can get their spirit read
- [[Shanya]] holds a small stone to the forehead, says an incantation, the stone shimmers and crystallises into a colour
- she drops the crystal into a cup of water, stirs it until it dissolves and the liquid fizzes
- she takes a pipette and drops a bit of the solution into her eye, then tells their spirit
- Ysgarlad - Red Crystal - Lion
- Brogan - Orange Crystal - Hare
- Woo - Green Crystal - Serpent
- Liri - Purple Crystal - After a delay she slams down one of her hands on the table, and clenches her eye with the other in pain
- "AHHHH, PLEASE, FORGIVE ME, FORGIVE ME etc."
- if the gang tries to help her, they see the bloodshot purple eye, she tells the gang to leave asap

#### Norbert's General
- general goods
![[Pasted image 20240327192419.png]]
#### Ironhand Forge
- the gang can turn the giant boar pelt into armour here
- sells armour and other clothes

### Plot 3 - Kiara's Deception
- The gang meets [[Kiara]] outside of the Cruster Guild along with [[Lunette]]
- they walk 10 minutes  around a mountain path, eventually arriving at the entrance to a cave, the [[Gloomstone Cavern]]
- As they walk through, eventually they encounter two skeletons
- after defeating the skeletons, they keep walking and walk into the ambush
- [[Kiara]] and [[Lunette]] lock them in the room, where they have to fight [[Gorbold the Gorgeful (statblock)]], [[Korgar the Spiked Menace (statblock)]] and [[Varthis the Cursed (statblock)]]
- Varthis resurrects the skeleton of [[Orson]]
- Eventually when they are on death's door, [[Liri]] screams to stop and emits a giant purple light
- feel an overwhelming magical force
- [[Liri]]'s power ends up killing the thugs, as well as knocking herself unconscious