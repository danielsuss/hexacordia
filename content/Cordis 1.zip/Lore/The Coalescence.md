---
aliases:
  - Origin
  - Creation
draft: "true"
---
### Synopsis
The Origin of the world.
### Notes
- Creation: 6 strongest beings in the [[Spiritual Plane]] decided to create their depiction of a perfect physical world, requiring 6 [[God Heart|god hearts]] to fuse together
	- the 6 beings were siblings, however had a 7th sibling who was always seen as the brunt of the group as he was not born with a god heart, mistreated and tossed aside
	- after much bullying, such as killing and eating the 7th's only [[Spirit Companion]], resentment built up inside the 7th sibling
	- thoughts of resentment were detected by the [[Eternal Shadow]]
		- the eternal shadow was sealed by the [[Everlasting Light]], in the [[War of the Spiritual Plane]], causing the everlasting light to split into 7 fragments, the 7 siblings
	- allowing the eternal shadow to manifest itself inside the 7th sibling
	- when the 6 beings decided to create the physical world, they were planning on abandoning the 7th in the spiritual plane for eternity
	- eternal shadow persuades the 7th to interrupt their plan
	- 7th manages to eat the god heart of the weakest of the 6, meaning that he becomes a part of the physical world instead of the weakest.
	- 7th now lies dormant in the new world, along with the other 5.