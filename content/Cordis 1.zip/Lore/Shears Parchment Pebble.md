---
draft: 
aliases:
---
###### Overview
- A game claimed to be invented by [[Gronk Growheart]]
- At the start of the game, players chant *"Shears! Parchment! Pebble!"* while shaking a closed fist up and down
- After the chant, each player throws out a chosen hand sign:
	- An extended pointer and index finger for shears
	- An open palm for parchment
	- A closed first for pebble
- The winner is decided on the following criteria:
	- Shears beats parchment
	- Parchment beats pebble
	- Pebble beats shears
- The last player remaining who has not been knocked out wins
- The gang played [[Shears Parchment Pebble]] to decide who would take guard duty on the second night of their journey to [[Rorkard]] with the [[Gilbreives|Gilbreivians]], with [[Ysgarlad]] taking the loss