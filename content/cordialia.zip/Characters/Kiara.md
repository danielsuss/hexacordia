---
draft: 
aliases:
  - Kiara's
---
*Human Female 22 [[Rorkard]]*
![[Pasted image 20240610202251.png]]
> *For my family's legacy, I will crush [[Rorkard]]!*
###### Overview
- [[Kiara]] is a mage from [[Rorkard]]
###### Appearances
###### [[Chapter 4 - Rorkard at Last]]
- Upon their first meeting, she asked [[Ysgarlad]] for help to carry crystals out of [[Gloomstone Cavern]]
###### [[Chapter 5 - Kiara's Deception]]
- Later told [[Ysgarlad]] the real reason was to go find [[Orson Emberfall]], who was last seen in [[Gloomstone Cavern]], upon which the gang agreed to go with her and [[Lunette Emberfall]] to find [[Orson Emberfall]]