---
draft: 
aliases:
---
*Human Male 65 [[Rorkard]]*
![[Pasted image 20240611140516.png]]
> *Welcome to [[Norbert's General]].*
###### Overview
- [[Norbert]] is a man from [[Rorkard]] and the owner of [[Norbert's General]]