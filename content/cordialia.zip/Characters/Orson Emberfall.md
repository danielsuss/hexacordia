---
draft: 
aliases:
  - Orson
---
*Undead Male 33 [[Rorkard]]*
![[Pasted image 20240611135239.png]]
> **
###### Overview
- [[Orson Emberfall]] was a warrior from [[Rorkard]] and the husband of [[Mirabel Emberfall]]
- He was known as the greatest warrior of [[Rorkard]], being the majority of their military force during the current age of peace
- He was lured by [[Kiara]] into [[Gloomstone Cavern]] during her scheme to destroy [[Rorkard]], where he is thought to have been killed by the [[Cannibals of Gloomstone Cavern]]
- He was then resurrected and used as an undead soldier by [[Varthis the Cursed]]
###### Appearances
###### [[Chapter 5 - Kiara's Deception]]
- The gang fought him when they had to fight the [[Cannibals of Gloomstone Cavern]]
- [[Orson's Scarf]] was taken by [[Ysgarlad]] to give to [[Mirabel Emberfall]], and one of each of [[Orson's Longswords]] were taken by [[Brogan Stone-Flask|Brogan]] and [[Woo Baby Woo|Woo]]
###### Gallery
|                                                                         |                                                                                                   |
| ----------------------------------------------------------------------- | ------------------------------------------------------------------------------------------------- |
| *Undead [[Orson Emberfall\|Orson]]*![[Pasted image 20240611135239.png]] | *[[Orson Emberfall\|Orson]] and [[Ciaran Emberfall\|Ciaran]]*![[Pasted image 20240611140122.png]] |
