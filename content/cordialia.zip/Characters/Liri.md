---
draft: 
aliases:
  - Liri's
---
*Sprite Female 10 ???*
![[Pasted image 20240423002234.png]]
> *Woaaaaah that was so cool!!*
###### Overview
- [[Liri]] is a young sprite that has been travelling with the gang since they found her in the [[Verdant Forest]]
###### Appearances
###### [[Chapter 3 - The Dangling Tradesman]]
- The gang found her trapped in a cage after killing the [[Kobold|Kobolds]] who stole [[Hoagle|Hoagle's]] bag
- [[Ysgarlad]] set her free however she came back to the gang after a day or so during their journey through the [[Verdant Forest]] towards [[Rorkard]] in search of food
- [[Liri]] decided to join the gang on their adventure after they showed her kindness
###### [[Chapter 4 - Rorkard at Last]]
- She helped [[Ysgarlad]] deliver a cake to [[Sarmon]] as requested by [[Elinor]]
- She was given a blue gem by [[Brogan Stone-Flask|Brogan]] which he stole from the [[Cruster Guild]]