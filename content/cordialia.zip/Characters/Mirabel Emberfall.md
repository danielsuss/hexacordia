---
draft: 
aliases:
---
*Human Female 32 [[Rorkard]]*
![[Pasted image 20240611133639.png]]
> **
###### Overview
- [[Mirabel Emberfall]] is a woman from [[Rorkard]] and the mother of [[Ciaran Emberfall]]
- Her husband was [[Orson Emberfall]]
###### Appearances
###### [[Chapter 5 - Kiara's Deception]]
- The gang first saw her crying at the noticeboard in the [[Rocky Refuge]], pinning up a notice for her lost husband
- Was then seen being comforted by [[Lunette Emberfall]]