---
aliases:
---
*Human Male 24 [[City of Isdal]]*
![[ysgarlad icon.png]]
> *Did you see who did it?! Hahahahaha*