---
draft: 
aliases:
---
*Human Male 34 [[Rorkard]]*
![[Pasted image 20240610200031.png]]
> *As long as they're a paying patron, anyone is welcome at the [[Rocky Refuge]]!*
###### Overview
- [[Sarmon]] is a man who lives in [[Rorkard]] and the owner of the [[Rocky Refuge]]
###### Appearances
###### [[Chapter 4 - Rorkard at Last]]
- He was delivered a cake from [[Elinor]] by [[Ysgarlad]] and [[Liri]]
###### [[Chapter 5 - Kiara's Deception]]
- Informed the gang that the [[Hooded Man]] was staying upstairs in the [[Rocky Refuge]]
- Demanded payment of 250GP from the gang after they destroyed a room in the [[Rocky Refuge]] whilst fighting the [[Hooded Man]], allowing them to stay at the inn while they collected the money