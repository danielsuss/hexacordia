---
draft: 
aliases:
---
*Tiefling Female ??? [[Rorkard]]*
![[Pasted image 20240611191615.png]]
> *What an intriguing spirit you have there.*
###### Overview
- [[Shanya]] is a spirit reader from [[Rorkard]] where she runs the shop [[Spirit Reader Shanya's]]
- She performs her spirit reading ritual using a small crystal, which changes colour when held to a person's head and activated
- The crystal is then dropped in water, dissolving and leaving a solution the same colour as the crystal
- She then takes a drop of the solution and drops it in her eye
###### Appearances
###### [[Chapter 5 - Kiara's Deception]]
- [[Shanya]] read each member of the gang's spirit
	- [[Ysgarlad]] depicted as a lone pensive lion with a red crystal
	- [[Brogan Stone-Flask|Brogan]] depicted as a strong three legged hare with an orange crystal
	- [[Woo Baby Woo|Woo]] depicted as an elegant white snake with a green crystal
	- When she read [[Liri|Liri's]] spirit, she freaked out, apologising profusely and begging for [[Liri]] to leave her alone - purple crystal