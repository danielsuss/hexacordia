---
aliases:
  - Woo
---
*High Elf Female 20 [[City of Virridius]]*
![[Pasted image 20240303102545.png]]