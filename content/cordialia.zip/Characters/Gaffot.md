---
draft: 
aliases:
---
*Human Male 45 [[Rorkard]]*
![[gaffot.webp]]
> *Me wife!*
###### Overview
- [[Gaffot]] is a man from [[Rorkard]]
###### Appearances
###### [[Chapter 5 - Kiara's Deception]]
- He met the gang at the [[Rocky Refuge]], where he is a frequent patron
- He has 27 wives