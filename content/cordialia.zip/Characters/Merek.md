---
aliases: 
draft:
---
###### Overview
- [[Merek]] is a man from [[Rorkard]]
- He runs a gambling stall in the commercial district of [[Rorkard]]
- He is a well known cheat, that makes his money off of his players by rigging his games
###### Appearances
###### [[Chapter 4 - Rorkard at Last]]
- Was scammed by [[Brogan Stone-Flask|Brogan]] and [[Woo Baby Woo|Woo]] at his own game, embarrassing him and causing a bit of an uproar