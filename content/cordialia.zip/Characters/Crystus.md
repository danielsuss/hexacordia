---
draft: 
aliases:
---
*Human Male 60 [[Rorkard]]*
![[Pasted image 20240610205904.png]]
> **
###### Overview
- [[Crystus]] is the leader of the [[Cruster Guild]] in [[Rorkard]]
###### Appearances
###### [[Chapter 4 - Rorkard at Last]]
- Was originally met by the gang and treated rudely by [[Ysgarlad]] upon their entrance to [[Rorkard]], as [[Ysgarlad]] did not know who he was and thought he was a beggar
- Later met the gang again at the [[Cruster Guild]], where he told them what he knew about the [[Fragment of the Eternal Shadow]], [[The Coalescence]] and [[Woo Baby Woo|Woo's]] [[Lodestone]]
###### [[Chapter 5 - Kiara's Deception]]
- Upon reclaiming the [[Fragment of the Eternal Shadow]] stolen by the [[Hooded Man]], the gang took it to be inspected by [[Crystus]]
- He confirms it is a [[Fragment of the Eternal Shadow]], however is no different to the few he has seen in the past