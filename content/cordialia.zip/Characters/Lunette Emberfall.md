---
draft: 
aliases:
  - Lunette
---
*Human Female 20 [[Rorkard]]*
![[Pasted image 20240611134458.png]]
> **
###### Overview
- [[Lunette Emberfall]] is a girl from [[Rorkard]] and the niece of [[Orson Emberfall]]
###### Appearances
###### [[Chapter 5 - Kiara's Deception]]
- Along with the gang and [[Kiara]] she went to [[Gloomstone Cavern]] to search for [[Orson Emberfall|Orson]]
- Ran away with [[Kiara]] when they trapped the gang with the [[Cannibals of Gloomstone Cavern]], however looking sorrowful