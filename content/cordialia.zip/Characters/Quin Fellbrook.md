---
aliases:
  - Quin
---
*Human Male 20 [[Gilbreives]]*
![[Pasted image 20240303214725.png]]
> *It's not easy being the best.*
###### Overview
- [[Quin Fellbrook]] is a man from the town of [[Gilbreives]]
- He won the [[Lumber Festival|wood chopping competition]] at the 82nd annual [[Lumber Festival]]
###### Appearances
###### [[Chapter 1 - The Lumber Festival]]
- Lost in a pint off to [[Brogan Stone-Flask|Brogan]], causing great embarrassment in front of [[Wren Briarwood]] who he is madly in love with
###### [[Chapter 2 - Into the Verdant Forest]]
- Was part of the group that travelled with the gang through the thick part of the [[Verdant Forest]] on their journey to [[Rorkard]]
- Inventor of [[Quin's Spice Blend]]
- Lost to [[Brogan Stone-Flask|Brogan]] in an eating competition to see who could eat the most spicy food, giving him a bag of his spice blend as a reward