---
draft: 
aliases:
  - Francindo's
---
*Human Male 42 [[Rorkard]]*
![[Pasted image 20240611140949.png]]
> *Here at the [[Ironhand Forge]] we only sell quality! Functional and fashionable.*
###### Overview
- [[Francindo]] is a man from [[Rorkard]] and the owner of the [[Ironhand Forge]]
###### Appearances
###### [[Chapter 5 - Kiara's Deception]]
- He bought [[Giant Boar]] pelt from [[Ysgarlad]] and [[Woo Baby Woo|Woo]]