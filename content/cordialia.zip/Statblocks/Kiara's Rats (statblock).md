---
draft: "true"
aliases:
---
## Basic Information
- **Size/Type**: Small Beast
- **Alignment**: Unaligned
- **Armor Class**: 14 (natural armor)
- **Hit Points**: 18 (4d6 + 4)
- **Speed**: 40 ft., climb 30 ft.
## Stats
- **STR**: 10 (+0)
- **DEX**: 17 (+3)
- **CON**: 12 (+1)
- **INT**: 2 (-4)
- **WIS**: 12 (+1)
- **CHA**: 5 (-3)
## Skills
- **Stealth**: +7
## Senses
- **Darkvision 60 ft.**
- **Passive Perception**: 11
## Challenge
- **CR 2 (450 XP)**
## Abilities
- **Keen Smell**: The enhanced giant rat has advantage on Wisdom (Perception) checks that rely on smell.
- **Pack Tactics**: The rat has advantage on an attack roll against a creature if at least one of the rat's allies is within 5 feet of the creature and the ally is not incapacitated.
## Actions
- **Bite**: Melee Weapon Attack: +6 to hit, reach 5 ft., one target. Hit: 9 (2d4 + 4) piercing damage. If the target is a creature, it must succeed on a DC 13 Constitution saving throw or be poisoned until the end of its next turn.
## Reactions
- **Intercept**: When a creature targets Kiara with an attack and the rat is within 5 feet of her, the rat can use its reaction to move in the path of the attack. The rat takes the attack instead of Kiara.
