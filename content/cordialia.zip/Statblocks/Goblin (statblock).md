---
draft: "true"
aliases:
---
![[Pasted image 20240412162127.png]]