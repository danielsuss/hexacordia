---
draft: "true"
aliases:
---
![[Pasted image 20240312150639.png]]