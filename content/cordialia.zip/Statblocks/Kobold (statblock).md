---
draft: "true"
aliases:
---


![[Pasted image 20240312145113.png]]