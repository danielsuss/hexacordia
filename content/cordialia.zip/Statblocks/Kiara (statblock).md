---
draft: "true"
aliases:
---
h## Basic Information
- **Size/Type**: Medium Humanoid
- **Alignment**: Chaotic Evil
- **Armor Class**: 15 (Natural armor)
- **Hit Points**: 90 (12d8 + 30)
- **Speed**: 30 ft.

## Stats
- **STR**: 12 (+1)
- **DEX**: 16 (+3)
- **CON**: 16 (+3)
- **INT**: 12 (+1)
- **WIS**: 14 (+2)
- **CHA**: 18 (+4)

## Saving Throws
- **Dex**: +6
- **Wis**: +5
- **Cha**: +7

## Skills
- **Deception**: +7
- **Stealth**: +6
- **Arcana**: +4

## Damage Resistances
- **Resistance to non-magical damage**

## Senses
- **Passive Perception**: 12

## Languages
- **Common**
- **Thieves' Cant**

## Challenge
- **CR 5 (1,800 XP)**

## Actions
- **Multiattack**: Kiara can make two attacks with her daggers.
- **Dagger**: Melee Weapon Attack: +6 to hit, reach 5 ft., one target. Hit: 7 (1d4 + 3) piercing damage.

## Spellcasting
Kiara is a 6th-level spellcaster. Her spellcasting ability is Charisma (spell save DC 15, +7 to hit with spell attacks). She has the following spells prepared:
- **Charm** (1st level): Attempts to charm a humanoid within range, making them regard Kiara as a friendly acquaintance until the spell ends.
- **Misty Step** (2nd level): Bonus action, teleport up to 30 feet to an unoccupied space that she can see.
- **Magic Shield** (3rd level): Reaction, when hit by an attack or targeted by the magic missile spell, Kiara can create an invisible barrier of magical force that appears and provides a +5 bonus to AC against that attack, including against the triggering attack.

## Special Actions
- **Summon Knife Rain** (3rd level): As an action, Kiara can cause a downpour of magical daggers to strike at a location she can see within 60 feet. Each creature in a 10-foot-radius, 40-foot-high cylinder centered on that point must make a Dexterity saving throw, taking 3d10 piercing damage on a failed save, or half as much damage on a successful one.
- **Summon Giant Rats** (3rd level): As an action, Kiara summons 3 giant rats [[Kiara's Rats (statblock)]] that appear in unoccupied spaces within 30 feet of her and act on her command. Each rat has its own initiative and obeys Kiara's verbal commands.

| 1st | 2nd | 3rd |
| --- | --- | --- |
| X   | X   | X   |
| X   | X   | X   |
|     |     | X   |
|     | X   | X   |
