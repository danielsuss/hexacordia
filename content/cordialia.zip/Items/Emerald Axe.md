###### Overview
- The [[Emerald Axe]] is a ceremonial weapon from the town of [[Gilbreives]]
- The winner of the [[Lumber Festival|wood chopping competition]] is allowed to take a swing at the [[Great Tree of Gilbreives]] with the axe
- A [[Fragment of the Eternal Shadow]] was embedded in the centre of the head before it was stolen by the [[Hooded Man]] 