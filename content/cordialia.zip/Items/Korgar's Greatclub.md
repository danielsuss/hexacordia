---
draft: "true"
aliases:
---
Korgar's Echo: Once per short rest, when the wielder successfully hits a creature with the Greatclub, they can choose to emit a terrifying roar similar to Korgar’s Menacing Roar. Any enemy within 15 feet must make a Wisdom saving throw or be frightened until the end of the wielder’s next turn. This echoes Korgar’s own fearsome presence on the battlefield.

