---
draft: 
aliases:
---
![[Aetherquartz Ring.webp]]
###### Overview
- A ring encrusted with a special blue [[Aetherquartz]] gem
- The ring is used in combination with [[Aetherquartz Powder]]
- After casting an incantation, the ring directs the user along the same travel line that the last [[Aetherquartz Powder]] to touch the user's skin travelled
- [[Brogan Stone-Flask]] used [[Hoagle|Hoagle's]] [[Aetherquartz Ring]] to track down the [[Kobold|Kobolds]] that stole [[Hoagle|Hoagle's]] magic bag
- After retrieving the bag, [[Hoagle]] gave [[Brogan Stone-Flask|Brogan]] an [[Aetherquartz Ring]] of his own as a reward