---
draft: 
aliases:
---
![[Orb of Varthis.webp]]