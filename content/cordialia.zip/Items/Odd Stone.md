---
draft: 
aliases:
---
###### Overview
- A stone with green runic inscriptions on it acquired by [[Woo Baby Woo]] from [[Hoagle]] as a reward for helping him get his magic bag back
- According to [[Crystus]] this type of stone is known as a [[Lodestone]] and can be used to imbue pieces of equipment with special properties by an [[Arcane Smith]]