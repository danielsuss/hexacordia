<%* const name = await tp.system.prompt("Enter Name") -%>
```
<%name %>:
	<% tp.file.cursor() %>
```