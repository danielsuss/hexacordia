---
draft: "true"
---
### Preface
- Gang killed the kobolds and helped Hoagle retrieve his bag
- Also freed a sprite who was being captured by the kobolds
- Reached Elinor's house, the old lady that Hoagle is visiting, decided to go in for tea
### Characters
[[Hoagle]]
[[Elinor]]
[[Liri]]
### Items

### Points of Interest
[[Verdant Forest]]
[[Elinor's Cabin]]
[[Rorkard]]
[[Rocky Refuge]]
[[Cruster Guild (Location)]]

### Plot 1 - Boar Infestation

## Entering Rorkard
![[rorkard.webp]]
- see an grey fluffy cat with green eyes sitting in a tree
- cat watching them as they enter
- look down to the right see children playing by the river skimming stones
- children look up and do the rorkard greeting and smile
- see a bald man fishing by the river
### Plot 2 - Rocky Refuge Inn and the Hooded Man
![[rorkard inn.webp]]
- the gang find sarmon at the bar and give him the cake from elinor etc.
- the cat approaches woo baby woo and gives the message

- the gang eventually gets approached by kiara
- kiara explains that they are looking for people to help them carry crystals from the mine
- gloomrock cavern in 2 days

- gang can seek out the hooded man
### Plot 3 - Spirit Reader Shanya's
![[Pasted image 20240319204045.png]]
- is empty, says she's out of town
### Plot 4 - Crystus and the Cruster Guild
![[cruster guild.webp]]
- if on the same day as meeting the fisherman crystus enters behind them
- tells them of the myth of how the world came to be
- "are you familiar with the story of the coalesence"