---
aliases:
  - Origin
  - Creation
draft:
---
###### Overview
- The story of how Cordisalia came into Existence
- According to [[Crystus]]
	- The 6 brothers of the spiritual plane fused to create Cordisalia, leaving behind [[Fragment of the Eternal Shadow|Fragments of the Eternal Shadow]] in random places around the world