---
aliases:
  - wood chopping competition
---
![[Pasted image 20240229220607.png]]
###### Overview
- A festival that takes place annually in the town of [[Gilbreives]]
- Drinking being merry, and not taking anything too seriously is heavily encouraged during the festival
- The festival's main event is the wood chopping competition, where people compete to see who can split the most wood in the allotted time
- The winner gets to take a swing at the [[Great Tree of Gilbreives]] using the [[Emerald Axe]]
- [[Gronk Growheart|Gronk]] holds the record for most wins in the wood chopping competition