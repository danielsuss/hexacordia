---
draft: "true"
aliases:
---
God of the Verdant Continent