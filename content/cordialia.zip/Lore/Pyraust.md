---
draft: "true"
aliases:
---
God of the Burning Expanse