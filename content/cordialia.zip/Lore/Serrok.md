---
draft: "true"
aliases:
---
God of the Arid Continent