---
draft: 
aliases:
---
![[Pasted image 20240229220403.png]]
###### Overview
[[Gilbreives]] is a large village on the [[Verdant Continent]]. It lies in the heart of the [[Verdant Forest]].
###### Characters from [[Gilbreives]]
- [[Gronk Growheart]]
- [[Grink Growheart]]
- [[Rowena Growheart]]
- [[Quin Fellbrook]]
- [[Wren Briarwood]]
###### Locations
- [[Gilbreives Town Hall]]
- [[Great Tree of Gilbreives]]
- [[Sleepy Leaf]]
###### Lore
- [[Lumber Festival]]
- [[Emerald Axe]]
###### Gallery
|                                                                      |                                                                      |
| -------------------------------------------------------------------- | -------------------------------------------------------------------- |
| *During the [[Lumber Festival]]*![[Pasted image 20240229220403.png]] | *During the [[Lumber Festival]]*![[Pasted image 20240229220607.png]] |
| *The [[Sleepy Leaf]] Inn*![[Pasted image 20240418182746.png]]        | *The North Gate*![[Pasted image 20240305171941.png]]                 |
| *[[Gilbreives Town Hall]]*![[Pasted image 20240418150624.png]]       |                                                                      |
