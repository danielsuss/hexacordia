---
draft: 
aliases:
---
![[rorkard.webp]]
###### Overview
[[Rorkard]] is a large settlement on the [[Verdant Continent]], lying at the foot of [[Florion's Ridge]].
###### Characters from [[Rorkard]]
- [[Crystus]]
- [[Sarmon]]
- [[Kiara]]
- [[Merek]]
- [[Gaffot]]
- [[Lunette Emberfall]]
- [[Norbert]]
- [[Francindo]]
- [[Shanya]]
- [[Orson Emberfall]]
- [[Mirabel Emberfall]]
- [[Ciaran Emberfall]]
###### Locations
- [[Rocky Refuge]]
- [[Cruster Guild]]
- [[Norbert's General]]
- [[Ironhand Forge]]
- [[Spirit Reader Shanya's]]
- [[Emberfall Household]]
- [[Rorkard Sewers]]
- [[Abandoned Thieves Guild]]
###### Gallery
|                                                                  |                                                             |
| ---------------------------------------------------------------- | ----------------------------------------------------------- |
| *[[Rorkard]]*![[rorkard 1.webp]]                                 | *The [[Cruster Guild]]*![[Pasted image 20240418185808.png]] |
| *[[Rocky Refuge]] Inn*![[rorkard inn 2.webp]]                    | *[[Ironhand Forge]]*![[Pasted image 20240418185756.png]]    |
| *[[Spirit Reader Shanya's]]*![[Pasted image 20240418185732.png]] | *[[Norbert's General]]*![[Pasted image 20240418185745.png]] |
| [[Emberfall Household]]![[Pasted image 20240419133311.png]]      | [[Rorkard Sewers]]![[SEWERS.webp]]                          |
| [[Abandoned Thieves Guild]]![[rorkard guild.webp]]               |                                                             |
