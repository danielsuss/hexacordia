---
aliases:
  - Boars
draft:
---
*Medium Beast [[Verdant Forest]]*
![[Pasted image 20240419140207.png]]
###### Overview
- A medium sized beast found in the [[Verdant Forest]]
- Considered a pest, the [[Boar|Boars]] of the [[Verdant Forest]] are gluttonous creatures often found grazing food from any source they find
- During their journey to [[Rorkard]] the gang had multiple encounters with [[Boar|Boars]]
	- [[Ysgarlad]] found multiple stealing food while on guard duty
	- [[Brogan Stone-Flask|Brogan]] suffered a leg impalement from the tusks of the [[Boar|Boars]] during their battle next to the [[River Midwood]]
	- At the request of [[Elinor]], the gang dispatched of the [[Boar|Boars]] raiding her crop garden, leading to their encounter with the [[Giant Boar]]
- Their meat is a popular meal throughout the [[Verdant Continent]], and so they are hunted and used as a means of trade, most notably by [[Gilbreives]]
###### Gallery
|                                                                                 |                                                                          |
| ------------------------------------------------------------------------------- | ------------------------------------------------------------------------ |
| *[[Boar\|Boars]] in the [[Verdant Forest]]*![[Pasted image 20240419140207.png]] | *[[Boar]] enraged with [[Ysgarlad]]*![[Pasted image 20240419142031.png]] |
|                                                                                 |                                                                          |
