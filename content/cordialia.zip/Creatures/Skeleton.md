---
draft: "true"
aliases:
---
![[Pasted image 20240327233742.png]]b