---
draft: 
aliases:
---
*Small beast ???*
![[Pasted image 20240423005511.png]]
###### Overview
- A rarer variant of [[Kobold]], more dragon-like and with wings
- The gang fought and killed one in the [[Verdant Forest]] while retrieving [[Hoagle|Hoagle's]] stolen magic bag