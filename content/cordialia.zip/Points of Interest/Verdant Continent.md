![[Verdant Continent.png]]
###### Overview
The [[Verdant Continent]] is one of the 6 continents of Cordisalia. It is a lush and fertile land with vast forests, diverse landscapes, and an abundance of wildlife.
###### Major Settlements
- [[City of Virridius]] *capital*
- [[Gilbreives]]
- [[Rorkard]]
- [[Bay of Groves]]
- [[Wyrmsgard]]
- [[Breisken]]
###### Other Settlements
- [[Kalskog]]
###### Other Points of Interest
- [[Verdant Forest]]
- [[River Midwood]]
- [[Gloomstone Cavern]]