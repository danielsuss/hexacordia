---
draft: "true"
aliases:
---
###### Overview
- [[Snøhaven]] is a major coastal settlement on the [[Frozen Highlands]]