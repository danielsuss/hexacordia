---
draft: 
aliases:
---
![[Pasted image 20240611191332.png]]
###### Overview
- [[Spirit Reader Shanya's]] is a magic store in [[Rorkard]] owned by [[Shanya]]
- All types of magical items can be found here, from spell scrolls to magic scrolls
- Offers a spirit reading service