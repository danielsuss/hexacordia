---
draft: 
aliases:
---
![[Pasted image 20240305175936.png]]
###### Overview
- The [[Verdant Forest]] is a vast forest covering a large portion of the [[Verdant Continent]]
- Through the middle runs the [[River Midwood]], which goes directly to [[Rorkard]]
- [[Elinor's Cabin]] lies along the [[River Midwood]] closer to [[Rorkard]]
- Features large coniferous trees, but is also home to a flourishing and diverse ecosystem of animals and shrubbery
###### Characters from the [[Verdant Forest]]
- [[Elinor]]
###### Creatures seen in the [[Verdant Forest]]
- [[Tuskhoof]]
- [[Boar]]
- [[Giant Boar]]
- [[Creatures/Kobold]]
- [[Winged Kobold]]
###### Gallery
|                                                               |                                                                   |
| ------------------------------------------------------------- | ----------------------------------------------------------------- |
| *[[River Midwood]] Day*![[Pasted image 20240305175936.png]]   | *[[River Midwood]] Evening*![[Pasted image 20240305181901.png]]   |
| *[[River Midwood]] Night*![[Pasted image 20240307192632.png]] | *[[Creatures/Kobold]] battle in the Verdant Forest*![[Midwood River 1.png]] |
