---
draft: 
aliases:
---
![[Pasted image 20240611140749.png]]
###### Overview
- The [[Ironhand Forge]] is an apparel store in [[Rorkard]] run by [[Francindo]]
- It sells "functional fashion", as said by [[Francindo]]
- The gang has visited quite a few times
	- Bought new clothes for [[Liri]] and [[Amara]]
	- [[Brogan Stone-Flask|Brogan]] bought a suit of studded leather armour