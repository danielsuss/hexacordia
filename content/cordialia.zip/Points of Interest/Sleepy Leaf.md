---
draft: 
aliases:
---
![[Pasted image 20240418182746.png]]
###### Overview
- The [[Sleepy Leaf]] is an inn in the town of [[Gilbreives]]
- The gang was provided refuge here by [[Grink Growheart|Grink]] after the events of the 83rd [[Lumber Festival]]