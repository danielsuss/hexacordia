---
draft: "true"
aliases:
---
###### Overview
- [[Lynhaven]] is a major settlement by the coast on the [[Frozen Highlands]]