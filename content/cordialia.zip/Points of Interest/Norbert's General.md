---
draft: 
aliases:
---
![[Pasted image 20240611140308.png]]
###### Overview
- [[Norbert's General]] is a general goods store run by [[Norbert]] in [[Rorkard]]
- Sells a wide array of items from potions to materials to basic weapons