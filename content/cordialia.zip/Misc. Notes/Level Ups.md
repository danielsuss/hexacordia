---
draft: "true"
aliases:
---
- Level 2 - Boars in Chapter 2
- Level 3 - Giant Boar in Chapter 4
- Level 4 - After bringing Amara back to Rorkard in Chapter 6