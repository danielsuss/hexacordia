---
draft: "true"
aliases:
---
#hidden 
- Layout: 6 kingdoms
	- each kingdom has a mountainous region, where the outcasts and sub speices of each kingdom live
	- this creates tension between the mountain folk and the citizens who live normally