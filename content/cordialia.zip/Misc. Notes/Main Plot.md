---
draft: "true"
aliases:
---
#hidden
### Main Plot

### Ant
- character they meet after

### Climax
- gang uses absolutely everything to defeat the final goliath. everyone is left super worn out as the final shadow heart emerges from the corpse of the kraken
- liri is unconscious from using her demon powers
- as gang watches, Ant finally reveals his identity, somehow paralysing the gang
- as they watch, he picks up liri's body floats into the air and fuses her with the final heart
- the gang gets frozen by something
- ant uses the power of the combined 6 hearts to flood the world, leaving only the mountains of each continent above sea level
- woos dream the world shall know our suffering, shall they drown, shall they suffocate, for too long we have been banished, flooded in this sunken wasteland, with the power of the shadow, they will regret ever forsaking us
