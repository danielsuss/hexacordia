---
draft: 
aliases:
---
![[Pasted image 20240305175936 1.png]]
As the gang forges ahead through the [[Verdant Forest]], three days pass without any form of conflict. However, a couple hours into the morning of day four this would all change.
```
???:
	HEEEEEELP! HEEEEEELP! SOMEBODY HELP!
```
The gang hears a male voice shouting for help coming from up ahead on the path. As they continue walking a figure of something dangling from a tree comes into sight.
```
???:
	HEEEEEEEEELP!
```
The shouting continues, and as they get closer, they realise that the shouts are coming from the dangling figure, which is actually man tied by his feet dangling upside down from a large tree. [[Woo Baby Woo|Woo]] remains cautious as ever, however [[Ysgarlad]] walks closer to inspect the situation, stopping next to the man.
```
???:
	Please man, you gotta help me! Please!
```
[[Ysgarlad]] reassures the man and tells him to calm down, and shoots a look over to [[Brogan Stone-Flask|Brogan]]. After taking a step back, [[Brogan Stone-Flask|Brogan]] leaps onto [[Ysgarlad]]'s shoulder, who in one strong motion launches [[Brogan Stone-Flask|Brogan]] towards the top of the rope like a shotput. [[Brogan Stone-Flask|Brogan]] slashes the rope with his axe, and due to [[Ysgarlad]]'s overwhelming strength lands face first in a hedge behind the tree. The man, a gnome, stands up in front of [[Ysgarlad]] and brushes the dirt off his shoulders. [[Ysgarlad]] peers down at the man who is only three and a half feet tall.
![[Pasted image 20240305173822 1.png]]
```
???:
	Thank you for your kindness!
```
The gnome nods and thanks [[Brogan Stone-Flask|Brogan]] and [[Ysgarlad]] before continuing.
```
???:
	The name's Hoagle, I'm a travellin' trader. I'll tell ya how I ended up in this situation. Last night I was walkin along this here path, gettin a bit dark, I probably shoulda stopped to rest. Before I knew it whoooooosh! I'm swept off my feet, danglin' from that tree. All of a sudden these- Kobolds- about two and a half foot tall, they come out from behind the bushes, cacklin', speakin' some foreign language! They come right at me, swipe my bag, cackle some more, and then they just walked off and left me danglin'!
```
[[Hoagle]] pauses and looks at each member of the gang. He seems like he has realised something.
```
Hoagle:
	Please guys, you gotta help me get my bag back! That's my whole career in there! you gotta help me get it back please you gotta understan-
```
[[Ysgarlad]] interrupts [[Hoagle]] and tells him to calm down, to take a breather. [[Ysgarlad]] discusses with the rest of the gang what to do. [[Woo Baby Woo|Woo]] seems disinterested in helping the gnome, but after a brief back and forth, they go back to speak with [[Hoagle]]. [[Ysgarlad]] asks if there will be a reward for their help.
```
Hoagle:
	Why of course! What do I look like to you? A goblin? Please, some respect. If you help me out, I'll give you each an item from my stock for free.
```
[[Brogan Stone-Flask|Brogan]] asks [[Hoagle]] how he expects them to find the [[Creatures/Kobold|Kobolds]]. [[Hoagle]] sticks out his hand for the gang to see and starts wiggling his fingers. On one of them is a silver ring with an encrusted blue gem. He holds out his other hand, in which is a small black pouch with a fine bright blue powder inside.
```
Hoagle:
	This here's an aetherquartz ring! When I cast the incantation, it'll point along the same line of travel as the last clump of aethquartz powder that touched my skin. You see, just before the Kobolds left, I threw some powder on them without them noticin. 
```
[[Hoagle]] takes a second to cast the incantation, after which, a small glowing blue circle appears in the gem of the ring. It spins around the circumference of the gem, before settling at a spot on the edge.
```
Hoagle:
	See! Looks like they went that way!
```
The ring appears to point in the same direction as the path towards [[Rorkard]]. [[Brogan Stone-Flask|Brogan]] stops [[Hoagle]] before they proceed, and states that they'll only help [[Hoagle]] get his bag back if he can wear the ring. After some back and forth [[Hoagle]] agrees to [[Brogan Stone-Flask|Brogan]]'s terms and hands over the ring. Fits like a glove, and so the gang sets off with [[Brogan Stone-Flask|Brogan]] at the lead. After about two hours of walking, the ring points in a different direction; to the left across the [[River Midwood]].
![[Midwood River.png]]
Peering over the river from the bank on the right, the gang sees some rustling in the vegetation, but can't make out any clear figures. Realising crossing over is inevitable, [[Ysgarlad]] looks towards [[Brogan Stone-Flask|Brogan]] and smiles. Deja vu? Long of the short of it, [[Ysgarlad]] tries to throw [[Brogan Stone-Flask|Brogan]] across, but he slips mid throw and [[Brogan Stone-Flask|Brogan]] ends up in the drink, unentertained. [[Brogan Stone-Flask|Brogan]] loses his left shoe to the current of the river. [[Ysgarlad]] tries to fish [[Brogan Stone-Flask|Brogan]] out of the river using his greatsword, but pissed off, [[Brogan Stone-Flask|Brogan]] instead tries to grab the sword and yank [[Ysgarlad]] in as well. [[Ysgarlad]] falls backwards onto the bank. He turns to [[Hoagle]] to throw him across as well.
```
Hoagle:
	Actually man.. I think I'm gonna stay over here. You guys look like you got this all undah control. Those lizards give me the heeby jeebies if ya know what im sayin'.
```
[[Ysgarlad]] shoots the gnome a stern look, who in turn backs himself onto a tree and makes it very clear that he doesn't want to move. Nevertheless, [[Ysgarlad]] parkours across the stones on to the left bank. As [[Brogan Stone-Flask|Brogan]] pulls himself up onto the island in the middle of the river, [[Woo Baby Woo|Woo]] hops across elegantly to the same point. Collecting themselves, they notice a strange line of sticks, stretching across the small landmass. Upon further inspection, they see a pair of red stones connected to either end of the sticks. [[Ysgarlad]] seems interested in what they're doing and starts shouting across the river.
```
Ysgarlad:
	OI- OOOIII! WHAS THA? WHAT YOU GUYS DOING?! WHA YOU LOOKIN AT?! OI-
```
[[Woo Baby Woo|Woo]] and [[Brogan Stone-Flask|Brogan]] debate throwing one of the red rocks at [[Ysgarlad]] to shut up his yapping, but realize that its probably a trap. They carefully step over the sticks, and jump across to [[Ysgarlad]] on the other side of the river, warning him to watch his step and tread lightly. [[Ysgarlad]] tells them not to worry, and points towards the rustling vegetation with a grin and a glint in his eye. Before anyone can say anything he charges full speed! After about 10 feet he is somehow flying through the air, his trajectory headed straight for the grass! A carefully strung tripwire caught him mid stride, causing trees to shake from which birds crow and scatter. The clashing of [[Ysgarlad|Ysgarlad's]] armour is loud as he crashes into the ground, landing flat, face down. Just as [[Brogan Stone-Flask|Brogan]] and [[Woo Baby Woo|Woo]] look at the knight on the floor in second hand embarrassment, they find a barrage of small stones flying fast in their direction. Managing to avoid the projectiles unscathed, they hear high pitched cackling coming from the same direction. They see four scaly figures, each about 3 foot tall.
![[Pasted image 20240419204723.png]]
Its the [[Creatures/Kobold|Kobolds]]! Three of them start walking towards the gang menacingly, whirling their slings around, loaded ready with more stones.
![[Pasted image 20240419204736.png]]
The last one has wings, and is standing next to the body of a [[Boar]] that looks like it was killed pretty recently. It picks up a heavy rock from nearby and takes flight towards the gang. It flies directly over [[Brogan Stone-Flask|Brogan]] and drops the rock on his head, causing heavy pain and disorientation. [[Woo Baby Woo|Woo]] fires off three magic missiles at the foe, one to each eye and one to the groin. The [[Winged Kobold]] splits into three pieces, its legs falling on top of [[Brogan Stone-Flask|Brogan]] and its torso getting blasted further away. In anger, the other three fire off more stones at [[Ysgarlad]], who is still on the floor. He tucks in his head, avoiding any damage and causing the stones to bounce off of his armour. With a chant of bardic inspiration from [[Brogan Stone-Flask|Brogan]], [[Ysgarlad]] picks himself up off of the ground and charges towards the [[Creatures/Kobold|Kobolds]]. He plants his leading foot and slashes the nearest one twice through with his greatsword, instantly killing it. He doesn't stop pushing. The second one looks up at him, paralysed in fear as [[Ysgarlad|Ysgarlad's]] shadow engulfs the three foot tall being. He plunges his sword deep through the chest of the scaly creature, hoisting it up into the air in triumph, before throwing the corpse into the surrounding shrubbery with a flick of his blade. The final remaining [[Kobold]], seeing its lizard comrades brutally killed, turns to flee. [[Woo Baby Woo|Woo]] fires off a second set of magic missiles at the foe, blasting through its back, killing the fourth and final [[Kobold]]. The gang stands up straight, collecting themselves in victory. They go to loot the bodies of the fallen, finding only 9 gold pieces to split between them. [[Brogan Stone-Flask|Brogan]] finds a boot in one of the [[Creatures/Kobold|Kobold's]] sacks, and takes it for his exposed left foot.
```
Hoagle:
	That was frickin' awesome man!
```
[[Hoagle]], who finally had managed to make his way across the [[River Midwood]], was now shaking his fists in excitement and slinging praise at the gang. He picks up a stick.
```
Hoagle:
	You were like ~mimicing Ysgarlad's sword slashes with the stick~ and then you were like ~waving the stick around like a wand~ it was sick man! ~Looks and points the stick at Brogan~ You were good too!
```
[[Ysgarlad]] grins at [[Hoagle|Hoagle's]] excitement.
```
Hoagle:
	Now, where is it? Where's my bag?!
```
[[Hoagle]] moves frantically towards the small clearing that was being used by the [[Creatures/Kobold|Kobolds]] as a camp. He finds his magic bag resting at the stump of a tree.
```
Hoagle:
	Yes! Here it is! Now, watch this!
```
He beckons the gang towards him, before taking his necklace off.
```
Hoagle:
	See without this necklace, no one can access my stuff.
```
He places the necklace on top of the bag, takes a step back, the kicks the bag causing a cloud of white smoke bigger than [[Ysgarlad]] to appear, engulfing [[Hoagle]] and the bag. When the smoke clears, where [[Hoagle]] was is now a small trading stand, with the gnome sitting on a stool on the other side of the vendors window.
```
Hoagle:
	Welcome to Hoagle's Haul! What can I do for ya? I got potions, rocks, trinkets, equipment, the lot! Each of ya can get somethin' for free as promised!
```
[[Ysgarlad]] chooses a healing potion. [[Woo Baby Woo|Woo]] chooses an [[Odd Stone]] with a slight green glow, and also decides to buy a [[Berserker Potion]]. [[Brogan Stone-Flask|Brogan]] wants to keep [[Hoagle|Hoagle's]] ring.
```
Hoagle:
	Man ya see that ring's special to me! I gotta get that back from you, it was my fathers.. But here look, I have the exact same ring just like it.
```
[[Hoagle]] rustles around in his stall before presenting [[Brogan Stone-Flask|Brogan]] with a new [[Aetherquartz Ring]] and a black pouch of [[Aetherquartz Powder]], as well as a scroll with the incantation to use it.
```
Hoagle:
	Be sparing with the powder, you can only get that on the Arid Continent.
```
As the gang are acquiring some new gear, they hear a high pitched voice.
```
???:
	Hey- Hey! Help!
```
As they look over to where the voice is coming from, they see what looks like a bird cage resting on top of a log. They walk over to the cage.
```
???:
	Hey! Let me out!
```
Inside they see a small humanoid girl in a tattered robe. She has light blue eyes and light blue wings.
```
Hoagle:
	Well I'll be damned, a sprite! Those lil' fellas are pretty rare!
```
The gang discusses what to do, with [[Ysgarlad]] and [[Woo Baby Woo|Woo]] being in favour of freeing the sprite. [[Brogan Stone-Flask|Brogan]] decides to agree, but makes a bet with [[Ysgarlad]] which he will win if their decision comes back to bite them in the ass. [[Ysgarlad]] walks over and crouches down by the cage and says hello to the sprite. The sprite pushes up against the back wall of the cage with a scared look. [[Ysgarlad]] unlocks the cage, and moves back to give the sprite some space. After some brief hesitation, the sprite bursts out of the door of the cage at high speed. Just before it flies away it pauses, turns around and looks at [[Ysgarlad]].
```
???:
	Th- thank you.
```
It then quickly disappears into depths of the forest. Everyone stands there looking puzzled for a minute, before gathering any last pieces of equipment, and making their way back across the [[River Midwood]] and back on to the path to [[Rorkard]].
```
Hoagle:
	Hey you guys, considerin' we're travellin' the same way and all, you think you could do a gnome a solid and let me travel with ya? My friends cabin is about two days outside of Rorkard.
```
The gang lets [[Hoagle]] tag along. And so they continue through the [[Verdant Forest]]. 

*Two days later...*

All seems peaceful, but after a couple day of travel everyone has a suspicion that something is watching them from within the forest. When they stop for lunch sat on a log, they can feel the presence again.
```
Hoagle:
	Hey, come out, we know you're there. No point in hidin'!
```
They hear a gasp, and then see a small figure hover slowly into vision. It is the same sprite from a couple of days before.
![[Pasted image 20240423002234.png]]
[[Brogan Stone-Flask|Brogan]] grins at [[Ysgarlad]]. The sprite slowly flies and lands on the ground in front of the group, clearly looking at the food they are eating.
```
???:
	Food, please, I haven't eaten- I don't know how long.
```
[[Ysgarlad]] breaks off a small piece of his bread and gives it to the sprite. She flies up and sits next to him on the log, before taking a gulp, and quickly digging in to the bread. [[Brogan Stone-Flask|Brogan]] looks at [[Ysgarlad]] and rubs his pointer finger and thumb together. [[Ysgarlad]] tuts and throws [[Brogan Stone-Flask|Brogan]] a gold piece. Before long, the gang has finished their lunch and has packed up to continue their journey. As they go to leave, they see that the sprite has peacefully fallen asleep on the log. Not wanting to leave her out in the open and in danger, [[Brogan Stone-Flask|Brogan]] carefully picks her up and puts her on his shoulder. The gang continues walking. By the time it is the late afternoon, a cosy log cabin comes into view.
![[Pasted image 20240423003101.png]]
```
Hoagle:
	Ahhhh here we are!
```
[[Hoagle]] runs up to the door, and knocks on it. An elderly woman opens the door, revealing the warm welcoming interior of the cabin.
![[Pasted image 20240423003243.png]]
```
Hoagle:
	Elinor! Good to see ya!
```
```
Elinor:
	Oh Hoagle, what a wonderful surprise! How lovely to see you, and I see you've brought some friends along.
```
[[Elinor]] looks at the gang who have also walked up to the cabin.
```
Elinor:
	How nice to meet you all, I am Elinor. Please, do come in for some tea and biscuits!
```
The gang each take a turn greeting [[Elinor]], and thank her for the offer.
```
Hoagle:
	Come on guys don't be shy!
```
The gang, feeling tired yet contempt with the progress of their journey thus far, decide to follow [[Hoagle]] into [[Elinor's Cabin]], the sprite still asleep on [[Brogan Stone-Flask|Brogan's]] shoulder.

*Our story continues in [[Chapter 4 - Rorkard at Last]]...*