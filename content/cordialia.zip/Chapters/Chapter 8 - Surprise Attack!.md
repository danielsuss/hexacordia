---
draft: 
aliases:
---
###### Abridged (WIP)
- gang took a short rest after killing morgrith in [[Morgrith's Lair]]
- woo used identify on the circlet of the occult, saw vision of lots of points connected to a central point
- [[Brogan Stone-Flask|Brogan]] used [[Morgrith the Mother|Morgrith]]'s claw to open the throne, netting the gang some gold
- teleportation circle lights up, teleports the gang to [[Kalskog]]
- get summoned on top of a roof in kalskog
- [[Kiara]] sees them and is very surprised, she starts running
- [[Ysgarlad]] dives off the roof and pins her down
- fight with kiara ensues...
- after tricky battle ysgarlad ends up knocking her out with the hilt of his sword
- gang drags her out into the forest, seen by an old drunkard
- brogan goes to see if the drunkard realised anything, ends up getting a mug of [[Skogbrew]]
- as they tie kiara up to a tree, blindfold her, they hear clip clopping from the forest
- two red wolves jump down from the trees and start snarling at the gang
- [[Crystus]] and [[Amara]] show up in a horse drawn cart, kiara tells the wolves to back down
- crystus is worried about morgrith, ysgarlad explains that they dealt with her
- crystus expresses his gratitude and says that he owes the gang
- ysgarlad asks amara if she wants to interrogate kiara, she gives the honour to ysgarlad
- ysgarlad wakes up and interrogates kiara
- learns that she wanted to destroy [[Rorkard]] for power and the legacy of her family who used to run the[[Abandoned Thieves Guild]]
- tells the gang to ask crystus about what happened to her family
- brogan and [[Woo Baby Woo|Woo]] are in the background bullshitting during the interrogation
- after he's done, ysgarlad nods to amara
- amara walks towards kiara, and points at her
- the two red wolves instantly leap at kiara and maul her to death before eating her
- amara releases the summon and the wolves disappear
- the gang heads back to rorkard in crystus' cart, they head to the [[Rocky Refuge]]
- in the rocky refuge they pay their debt to [[Sarmon]], before celebrating
- they hear a monsterous laugh from the entrance, its none other than [[Gronk Growheart|Gronk]]
- they catch up with him and ysgarlad returns the [[Fragment of the Eternal Shadow]] to gronk, who thanks him and slams it down on a table
- the gang get drunk with gronk
- [[Liri]] touches the fragment of the eternal shadow, causing it to crack, releasing a powerful blast of purple energy, recking the interior of the tavern and sending everyone bar herself flying
- she has purple sparks around her body, her wings and eyes have turned purple
- she faints
- the fragment is now in two pieces, no longer purple, but a dull grey
- gronk is too drunk to care about the fragment, and falls asleep on the floor
- sarmon is seen holding his head in his hands
- the gang go upstairs to rest

*Our story continues in [[Chapter 9 - Florion's Tears]]...*