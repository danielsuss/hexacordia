---
draft: 
aliases:
---
###### Abridged (WIP)
- Gang learn more about [[Liri]] at [[Elinor's Cabin]]
- Gang helped [[Elinor]] by killing the [[Boar|Boars]] and the [[Giant Boar]]
- finally made it to [[Rorkard]] and were greeted by a fisherman
- [[Ysgarlad]] and [[Liri]] Delivered a cake to [[Sarmon]] at the [[Rocky Refuge]]
- [[Ysgarlad]] approached by [[Kiara]] requesting help in 2 days time to carry crystals out of [[Gloomstone Cavern]]
- [[Brogan Stone-Flask|Brogan]] and [[Woo Baby Woo|Woo]] made some money by cheating a gambler called [[Merek]] at his own game
- [[Woo Baby Woo|Woo]] was delivered a secret note by a cat from [[Post Mortem]] stating that the [[Hooded Man]] is resting in the tavern
- The gang reconvened at the [[Cruster Guild]], seeking out [[Crystus]], end up running into the fisherman again, who turns out to be [[Crystus]]
- [[Woo Baby Woo|Woo]] asks [[Crystus]] about the [[Odd Stone]], he says its a special type of ancient runic stone called a [[Lodestone]] that can be used to make special equipment
- The gang ask [[Crystus]] about the [[Fragment of the Eternal Shadow]], he tells them about [[The Coalescence]]
- [[Brogan Stone-Flask|Brogan]] steals a blue gem for [[Liri]]
- The gang return to the [[Rocky Refuge]] in search of the [[Hooded Man]]

*Our story continues in [[Chapter 5 - Kiara's Deception]]...*