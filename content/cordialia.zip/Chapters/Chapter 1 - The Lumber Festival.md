![[Pasted image 20240229220403.png]]
At the 83rd annual [[Lumber Festival]] of the Forest town [[Gilbreives]] in the [[Verdant Continent]], howls of laughter can be heard from a crowd gathered around a man telling his stories.
![[Pasted image 20240229220442.png]]
Attending the festival are also 4 individuals, who seem to have nothing in common, apart from the fact that they are the only people not laughing at the man's story. After seeing this, the man calls them out, demanding them to state their name and their case. Among the four, a Dwarf, [[Brogan Stone-Flask]] who flips a coin between his fingers while chugging down mugs of ale. A [[Hooded Man]], the only thing visible on his face a black goatee, who says nothing. An elf, [[Woo Baby Woo]], who throws insults at the man after he makes misogynistic advances. A human named [[Ysgarlad]], who introduces himself and then instantly challenges the man to an arm wrestle! The man accepts, betting 15 gold coins against [[Ysgarlad]]'s 5. Brogan bets 9 on [[Ysgarlad]] to win. After putting up a meagre amount of resistance, [[Ysgarlad]] loses. The crowd roars with laughter and the man scoops up his winnings.
```
???:
	I didn't expect you to be this weak! Hahahahaha!
```
The man finally introduces himself as [[Gronk Growheart]], the record holder for the most chops using the [[Emerald Axe]] against the [[Great Tree of Gilbreives]]. He then tells the gang about the wood chopping competition about how the winner gets to swing the [[Emerald Axe]], and welcomes them to [[Gilbreives]] and tells them to enjoy the festival. He seems to be very popular with the ladies. [[Gronk Growheart|Gronk]] notices that amongst all of the commotion that the fourth man has disappeared, but blames it on himself being drunk and convinces himself that there wasn't a fourth individual after all. After the crowd returns to normal, [[Ysgarlad]] decides to go look for the [[Hooded Man]], whom he happens to see walking towards the town hall. While [[Ysgarlad]] follows the mysterious figure, [[Brogan Stone-Flask|Brogan]] and [[Woo Baby Woo|Woo]] decide to go enter themselves in the wood chopping competition.
![[Pasted image 20240229220607.png]]
Entering the [[Gilbreives Town Hall]], [[Ysgarlad]] finds nothing inside, apart from an old man sleeping in a throne.
![[Pasted image 20240418150551.png]]
He decides to wake the old man up, stating that he saw a shady figure enter the hall. Startled, the old man implores [[Ysgarlad]] to check the treasure room, hidden behind a trick bookshelf at the end of the hall. Upon realising that the old man has no intention of tricking him, [[Ysgarlad]] follows the order, and enters the treasure room. He finds a room full of gold trinkets, with a large empty pedestal central in the room. Looking down to his feet, [[Ysgarlad]] finds two guards who are unconscious. After waking one up with the smell of his boot, the guard gathers his thoughts and tells [[Ysgarlad]] that within the blink of an eye a hooded figure had knocked both guards unconscious. The guard then looks to the pedestal and realises what is missing. He runs to tell the old sleepy man.
```
Guard:
	It's missing! The Emerald Axe is gone!
```
The old Man scowls in disbelief, and pleads with the guard and [[Ysgarlad]] to go inform the rest of the town of what has happened. All the meanwhile, [[Brogan Stone-Flask|Brogan]] and [[Woo Baby Woo|Woo]] have entered into the [[Lumber Festival|wood chopping competition]]. While they wait for it to start, [[Brogan Stone-Flask|Brogan]] challenges the man standing next to him, to a pint off. The man accepts and introduces himself as [[Quin Fellbrook]], the man to last win the [[Lumber Festival|wood chopping competition]]. [[Brogan Stone-Flask|Brogan]] opens his throat and gulps his pint in one. On the contrary, [[Quin Fellbrook|Quin]] chokes on his drink and runs away in embarrassment dropping two gold coins on his way out. Laughter can be heard from [[Gronk Growheart|Gronk]], who was looking on from a distance. [[Ysgarlad]] and the guard come running to find [[Gronk Growheart|Gronk]], telling him that the axe has been stolen. [[Gronk Growheart|Gronk]] panics, and notifies everyone to find the axe as fast as possible. This attracts the attention of [[Brogan Stone-Flask|Brogan]] and [[Woo Baby Woo|Woo]]. After providing some comfort to an official running the chopping competition they decide to go help [[Ysgarlad]] and [[Gronk Growheart|Gronk]] find the [[Emerald Axe]]. [[Gronk Growheart|Gronk]] sprints off officer Earl style.
![[run.mp4]]
[[Woo Baby Woo|Woo]] spots some commotion in the distance; the [[Hooded Man]] pushing through a crowd of people, trying to escape towards the north gate of the town. As they run towards the north gate, [[Brogan Stone-Flask|Brogan]] riding on [[Woo Baby Woo|Woo]]'s shoulders, the hooded man comes into vision. Just as the man is about to escape, [[Gronk Growheart|Gronk]] crashes down in front of him, jumping from a tree.
```
Gronk:
	I've got you now you scoundrel! Hahahahahaha!
```
The hooded man decides to turn and face our gang of three, holding a big weapon wrapped in bandages. [[Ysgarlad]] decides to try to tackle the man, however trips over his own foot and lands with dust in his eyes. [[Gronk Growheart|Gronk]] roars with laughter from a distance. [[Brogan Stone-Flask|Brogan]] also tries to tackle the man, wrapping his arms around his legs, however is ripped off and thrown aside into a pillar of the gate. [[Gronk Growheart|Gronk]] laughs again.
```
Gronk:
	You guys are worthless! Hahahahahaha!
```
The hooded man starts murmuring a spell and unbandages the weapon, a heavy battle axe glinting bright green in the sunlight a small shadowy jewel embedded in the centre of the head. The [[Emerald Axe]]! He rips the purple jewel from the head with his right hand, tossing the axe to the floor. Angered by this, [[Gronk Growheart|Gronk]] swiftly grabs the man by the neck and hoists him into the air. The man chants his spell faster and a portal starts to form around him. When the spell is complete the portal disappears, along with the man, and half of [[Gronk Growheart|Gronk]]'s Arm. [[Gronk Growheart|Gronk]] screams in pain. [[Brogan Stone-Flask|Brogan]] yells to the crowd for a healer, resulting in a lady to come running to [[Gronk Growheart|Gronk]]'s aid. His wife. The gang look at each other in irony, thinking of [[Gronk Growheart|Gronk]]'s manly behaviour all the while having a wife. The lady casts a spell which cauterizes the wound on his arm. Thinking he was whispering, [[Brogan Stone-Flask|Brogan]] yells a joke in the ear of [[Woo Baby Woo|Woo]], remarking about [[Gronk Growheart|Gronk]]'s arm.
```
Brogan:
	I GUESS HE'S ARMLESS NOW!
```
With everyone in the crowd falling silent cringing at the distastefulness of [[Brogan Stone-Flask|Brogan]]'s joke, [[Gronk Growheart|Gronk]]'s wife strides over to [[Brogan Stone-Flask|Brogan]] and back hands him, causing to fly into the pillar again. This leaves [[Gronk Growheart|Gronk]] laughing, although wincing in pain too. After he finally stands up, [[Gronk Growheart|Gronk]] picks up the axe with his remaining arm, and gives it a practice swing. It no longer shines bright green, and instead looks dull and decrepit.
```
Gronk:
	We must inform my father of this.
```
[[Gronk Growheart|Gronk]] marches off with the [[Emerald Axe]] towards the [[Gilbreives Town Hall]] with his wife. The three follow him. Upon entry, the three find [[Gronk Growheart|Gronk]] kneeling in front of the old man sitting in the chair, holding the axe up, a sad look across his face. [[Gronk Growheart|Gronk]] notices the three.
```
Gronk:
	Ah Ysgarlad, this is my father-
```
```
???:
	Yes we have met once already.
```
[[Gronk Growheart|Gronk]] has a confused look on his face, as the old man continues.
```
???:
	I am Grink Growheart, father of Gronk and leader of Gilbreives.
```
[[Grink Growheart|Grink]] then continues to thank the three for their help in trying to retrieve the axe, and looks puzzled about the situation. [[Woo Baby Woo|Woo]] asks if the man stole the gemstone from the axe because it was a [[Fragment of the Eternal Shadow]].
```
Grink:
	Where did you learn that name?
```
[[Grink Growheart|Grink]] a shoots a serious look at [[Woo Baby Woo|Woo]]. She explains that she once read about a similar gemstone in a page torn out of a book.
```
Grink:
	I have only heard that name once before - and I was told not to throw it around loosely. Perhaps though, as you seem to already know this name, you may be the most suitable person in Gilbreives to retreive the stone. What do you say?
```
[[Woo Baby Woo|Woo]] and the rest of the gang look at each other, before [[Woo Baby Woo|Woo]] looks back to [[Grink Growheart|Grink]] and nods. [[Grink Growheart|Grink]] strokes his beard pensively.
```
Grink:
	Alright, It might be worth looking for information from the one man who told me that name years ago. He's much more an expert than I am. His name is Crystus, Crystus of the Cruster Guild.
```
[[Grink Growheart|Grink]] then hands the three a two sided map. On one side a map of Cordisalia, on the other a more detailed map of the [[Verdant Continent]].
![[Pasted image 20240229221155.png]]
![[Pasted image 20240229221207.png]]
```
Grink:
	Crystus resides in Rorkard, a village at the foot of the mountains about 2 weeks northwest of here by foot. Perhaps if you speak to him he might tell you more about the stone and why that man wanted it. We can provide aid for you to make the journey as you see fit.
```
As [[Ysgarlad]] and [[Grink Growheart|Grink]] talk back and forth about provisions for the journey, [[Brogan Stone-Flask|Brogan]] asks [[Gronk Growheart|Gronk]] if he saw the [[Hooded Man]]'s face.
```
Gronk:
	He had black facial hair, glowing purple eyes, and scarred ragged skin.
```
Upon hearing this information, [[Woo Baby Woo|Woo]] decides to head to an information outpost in the south of the village to send a message to the syndicate [[Post Mortem]] regarding the visual features of the [[Hooded Man]]. She finds a kid in a shed, who upon hearing the code word transforms into a tall lanky man, agreeing to distribute the information as he sees fit. Upon returning to the town hall, [[Ysgarlad]] and [[Grink Growheart|Grink]] have finished discussing the trip to [[Rorkard]]. Men from [[Gilbreives]] will take the three halfway to [[Rorkard]] by horseback, from where they will complete the rest by foot. [[Gilbreives]] will provide supplies for the journey. Finally, as the sun is setting [[Grink Growheart|Grink]] provides rooms at the  [[Sleepy Leaf]], an inn for the three to sleep, with the plan being to set out in the morning.

*Our story continues in [[Chapter 2 - Into the Verdant Forest]]...*